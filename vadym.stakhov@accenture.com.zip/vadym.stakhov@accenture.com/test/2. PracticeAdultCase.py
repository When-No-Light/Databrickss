# Databricks notebook source
# MAGIC %md
# MAGIC ##### 1. Wylistuj pliki znajdujące się w obrębie folderu 'adult' z wbudowanej ścieżki dostępu do ogólnodostępnych datasetów w dbfs

# COMMAND ----------

dbutils.fs.ls("dbfs:/databricks-datasets/adult/")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 2. Zlokalizuj nazwy kolumn w obrębie plików i odczytaj plik csv z danymi przypisując im jednocześnie nazwy kolumn.
# MAGIC ######Nazwij zmienna dataframe "adultFrame"

# COMMAND ----------

# MAGIC %md
# MAGIC #Attributes:
# MAGIC - age: continuous
# MAGIC - workclass: Private
# MAGIC - fnlwgt: continuous
# MAGIC - education: Bachelors
# MAGIC - education-num: continuous
# MAGIC - marital-status: Married-civ-spouse
# MAGIC - occupation: Tech-support
# MAGIC - relationship: Wife
# MAGIC - race: White
# MAGIC - sex: Female
# MAGIC - capital-gain: continuous
# MAGIC - capital-loss: continuous
# MAGIC - hours-per-week: continuous
# MAGIC - native-country: United-States

# COMMAND ----------

retail_rdd = sc.textFile("dbfs:/databricks-datasets/adult/adult.data")
for x in retail_rdd.take(20):
    print(x)

# COMMAND ----------

# 

# schema = StructType([
#     StructField("age", IntegerType(), True),
#     StructField("workclass", StringType(), True),
#     StructField("fnlwgt", DoubleType(), True),
#     StructField("education", StringType(), True),
#     StructField("education_num", StringType(), True),
#     StructField("marital_status", StringType(), True),
#     StructField("occupation", StringType(), True),
#     StructField("relationship", StringType(), True),
#     StructField("race", StringType(), True),
#     StructField("sex", StringType(), True),
#     StructField("capital_gain", DoubleType(), True),
#     StructField("capital_loss", DoubleType(), True),
#     StructField("hours_per_week", DoubleType(), True),
#     StructField("native_country", StringType(), True),
# ])

# adultFrame = spark.read.csv("dbfs:/databricks-datasets/adult/adult.data",header=False,schema=schema )
# adultFrame.show(200)

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType

schema = StructType([
    StructField("age", IntegerType(), True),
    StructField("workclass", StringType(), True),
    StructField("fnlwgt", DoubleType(), True),
    StructField("education", StringType(), True),
    StructField("education_num", StringType(), True),
    StructField("marital_status", StringType(), True),
    StructField("occupation", StringType(), True),
    StructField("relationship", StringType(), True),
    StructField("race", StringType(), True),
    StructField("sex", StringType(), True),
    StructField("capital_gain", DoubleType(), True),
    StructField("capital_loss", DoubleType(), True),
    StructField("hours_per_week", DoubleType(), True),
    StructField("native_country", StringType(), True),
])

adultFrame = (spark
                 .read
                 .format("csv")
                 .option("delimiter", ", ")
                 .options(header="false")
                 .schema(schema)
                 .load("dbfs:/databricks-datasets/adult/adult.data")
                 
            )

adultFrame.printSchema()
display(adultFrame)

# COMMAND ----------

# MAGIC %md
# MAGIC #####3. Określ rozmiar tabeli i wylistuj kolumny
# MAGIC ###### 3.1. określ liczbę braków danych względem każdej kolumny

# COMMAND ----------

adultFrame.count()

# COMMAND ----------

adultFrame.columns

# COMMAND ----------

import pyspark.sql.functions as F

adultFrame.select([F.count(F.when(F.isnan(c), c)).alias(c) for c in adultFrame.columns]).show()

# COMMAND ----------

adultFrame.select([F.count(F.when(F.col(c)=='?', c)).alias(c) for c in adultFrame.columns]).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 4. Zadania Analityczne
# MAGIC 4.1. Zwróć pierwsze 25 rekordów\
# MAGIC 4.2. Oszacuj medianę wieku osób rozwiedzionych\
# MAGIC 4.3. Oszacuj różnicę między największą, a najmniejszą liczbą przepracowanych godzin pogrupowanej względem workclass i native country

# COMMAND ----------

adultFrame.show(25)

# COMMAND ----------

from pyspark.sql import Window


mediana = adultFrame.where(col("marital_status")=="Divorced").groupBy('marital_status').agg(F.expr('percentile_approx(age, 0.5)'))
mediana.show()

# COMMAND ----------

 Oszacuj różnicę między największą, a najmniejszą liczbą przepracowanych godzin pogrupowanej względem workclass i native country

# COMMAND ----------

liczba_h = (adultFrame
        .groupBy('workclass', 'native_country')
        .agg(
            F.min("hours_per_week").alias("Min_number_hours"),
            F.max("hours_per_week").alias("Max_number_hours"),
        )
        .withColumn("difference", (F.col("Max_number_hours")-F.col("Min_number_hours")))
           )
liczba_h.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 5. Utwórz nową kolumnę (adultStrings), która stworzy string z wszystkich kolumn typu string (nie usuwaj kolumn, które posłużą do wykonania tego punktu)

# COMMAND ----------

adultFrame.select(concat(col("fname"),lit(','),
    col("mname"),lit(','),col("lname")).as("FullName"))
      .show(false)

# COMMAND ----------

string_col_l = []
for c in adultFrame.dtypes:
    if c[1] == 'string':
        string_col_l.append(c[0])
        
string_col_l

# COMMAND ----------

concat = (
    adultFrame
    .select
    (F.concat(
        col("workclass"),F.lit(','),           
        col("education"),F.lit(','),
        col("education_num"),F.lit(','),
        col("marital_status"),F.lit(','),
        col("occupation"),F.lit(','),
        col("relationship"),F.lit(','),
        col("race"),F.lit(','),
        col("sex"),F.lit(','),
        col("native_country"),)
     .alias("adultStrings")))

# COMMAND ----------

display(concat)

# COMMAND ----------


# type(adultFrame.collect()[0]['hours_per_week'])

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 6. Utwórz nowy kontener pod nazwą 'practicedayadult[ inicjał imienia i nazwiska ]'

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ##### 7. korzystając z Databricks CLI lub Azure Key vault utwórz nowy scope pod nazwą "practicedayadultscope"
# MAGIC ###### 7.1. zapisz w nim klucz do storage account
# MAGIC ###### 7.2. korzystając z scope'a zmountuj kontener pod nazwa "practicedayadultmount"

# COMMAND ----------

storageContainer = "practicedayadultmount"
storageKey = dbutils.secrets.get(scope = "practicedayadultscope", key = "practicedayadultscope")
storageName = "vsrg2t7b5vl27dv2astore"
spark.conf.set(
    f"fs.azure.account.key.{storageName}.dfs.core.windows.net",
    dbutils.secrets.get(scope = "practicedayadultscope",key = "practicedayadultscope"))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 8. Korzystając z mounta utwórz w nim folder "practicedayadultfolder"

# COMMAND ----------

storageKey = "SLKcAcJR5Yt8tjEKoYDaY3kzHlf0z13oFsCo57MMh0i1keer3C44s9APtGzE34QoS9ItU6GbhPBiO4DZiZ6tow=="

# COMMAND ----------

dbutils.fs.mount(
 source = "wasbs://{0}@{1}.blob.core.windows.net".format(storageContainer, storageName),
 mount_point = "/mnt/practicedayadultfolder",
 extra_configs = {"fs.azure.account.key.{0}.blob.core.windows.net".format(storageName): storageKey}
)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ##### 9. Podziel plik na dwie części w proporcji 70:30% pod względem liczby rekordów.
# MAGIC ###### 9.1. Nazwij zmienne dataFrame adultFrameTraining, adultFrameTest

# COMMAND ----------

adultFrameTraining, adultFrameTest = adultFrame.randomSplit(weights=[0.7,0.3], seed=200)


# COMMAND ----------

# MAGIC %md
# MAGIC ##### 10. Zapisz pliki adultFrameTraining, adultFrameTest do nowo utworzonego folderu przy pomocy mounta jako PARQUET (liczba PARTS w obu parquetach powinna być równa 1)
# MAGIC ###### 10.1. Wylistuj wnętrze obu zapisanych plików przy pomocy mounta w celu określenia z ilu partów złożony jest parquet

# COMMAND ----------

adultFrameTraining.repartition(1).write.mode("overwrite").format("parquet").save("/mnt/practicedayadultfolder")

# COMMAND ----------

adultFrameTest.repartition(1).write.mode("overwrite").format("parquet").save("/mnt/practicedayadultfolder")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 11. Odczytaj oba pliki parquet i zapisz jako jedną zmienną "adultFrameParq"

# COMMAND ----------

adultFrameParq=spark.read.parquet("/mnt/practicedayadultfolder")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### *12. przedstaw 10 najczęściej występujących słów w obrębie płci dla "adultStrings"
# MAGIC ###### **12.1. Spróbuj rozwiązania z pominięciem stopwordów

# COMMAND ----------

# MAGIC %md
# MAGIC #####*13. Skorzystaj z automl dzięki adultFrameTraining i zrób prognozę dla adultFrameTest