# Databricks notebook source
data_cities = [
    {"City":"Atlanta","State":"GA","Country":"USA","Area":343.0,"Population":420003},
    {"City":"Chicago","State":"IL","Country":"USA","Area":606.1,"Population":2763076},
    {"City":"Las Vegas","State":"NV","Country":"USA","Area":340.0,"Population":583756},
    {"City":"Los Angeles","State":"CA","Country":"USA","Area":1302.0,"Population":3999759},
    {"City":"New York","State":"NY","Country":"USA","Area":1213.3,"Population":8336817},
    {"City":"Ottawa","State":"ON","Country":"Canada","Area":2778.64,"Population":945438},
    {"City":"Quebec","State":"PQ","Country":"Canada","Area":485.77,"Population":531902},
    {"City":"San Francisco","State":"CA","Country":"USA","Area":600.7,"Population":852469},
    {"City":"Seattle","State":"WA","Country":"USA","Area":217.4,"Population":713211},
    {"City":"Toronto","State":"ON","Country":"Canada","Area":841.0,"Population":2615060},
    {"City":"Washington DC","Country":"USA","Area":177.0,"Population":705749},
]

data_people = [
    {"firstName":"Philomena","middleName":"Jacinta","lastName":"Thunnerclef","gender":"F","birthDate":"1978-11-25T05:00:00.000Z","city":"Ottawa","salary":86568},
    {"firstName":"Eugena","middleName":"Annelle","lastName":"Lupton","gender":"F","birthDate":"1994-06-17T04:00:00.000Z","city":"Ottawa","salary":64352},
    {"firstName":"Natashia","middleName":"Dale","lastName":"Dulwitch","gender":"F","birthDate":"1993-01-23T05:00:00.000Z","city":"Ottawa","salary":94529},
    {"firstName":"Damaris","middleName":"June","lastName":"Roskell","gender":"F","birthDate":"1954-09-16T04:00:00.000Z","city":"Toronto","salary":23155},
    {"firstName":"Tatyana","middleName":"Janet","lastName":"Jurkowski","gender":"F","birthDate":"1953-11-20T05:00:00.000Z","city":"Toronto","salary":56372},
    {"firstName":"Simone","middleName":"Chery","lastName":"Fallis","gender":"F","birthDate":"1989-06-24T04:00:00.000Z","city":"Toronto","salary":84961},
    {"firstName":"Isabell","middleName":"Keiko","lastName":"Chaves","gender":"F","birthDate":"1972-12-07T05:00:00.000Z","city":"Toronto","salary":70857},
    {"firstName":"Valery","middleName":"Sarah","lastName":"Eagles","gender":"F","birthDate":"1956-03-20T05:00:00.000Z","city":"Washington DC","salary":103307},
    {"firstName":"Moira","middleName":"Kathrine","lastName":"Wotton","gender":"F","birthDate":"1999-05-17T04:00:00.000Z","city":"Washington DC","salary":48722},
    {"firstName":"Athena","middleName":"Alma","lastName":"Lethem","gender":"F","birthDate":"1983-07-02T04:00:00.000Z","city":"Washington DC","salary":37678},
    {"firstName":"Ching","middleName":"Lidia","lastName":"Stelfax","gender":"F","birthDate":"1959-06-02T04:00:00.000Z","city":"Washington DC","salary":81668},
    {"firstName":"Eve","middleName":"Kori","lastName":"Wilder","gender":"F","birthDate":"1955-08-23T04:00:00.000Z","city":"Washington DC","salary":59202},
    {"firstName":"Steve","middleName":"Ollie","lastName":"Cullinan","gender":"M","birthDate":"1977-12-27T05:00:00.000Z","city":"Los Angeles","salary":69806},
    {"firstName":"Carter","middleName":"Israel","lastName":"Chapellow","gender":"M","birthDate":"1970-12-17T05:00:00.000Z","city":"Los Angeles","salary":70563},
    {"firstName":"Rolland","middleName":"Marshall","lastName":"Cleave","gender":"M","birthDate":"1974-06-27T04:00:00.000Z","city":"Los Angeles","salary":74752},
    {"firstName":"Mikel","middleName":"Orville","lastName":"MacFayden","gender":"M","birthDate":"1989-07-06T04:00:00.000Z","city":"Chicago","salary":24715},
    {"firstName":"Darrel","middleName":"Raleigh","lastName":"Wisker","gender":"M","birthDate":"1953-08-21T04:00:00.000Z","city":"Chicago","salary":53961},
    {"firstName":"Ernie","middleName":"Boyd","lastName":"Yosselevitch","gender":"M","birthDate":"1990-07-03T04:00:00.000Z","city":"Chicago","salary":25347},
    {"firstName":"Pat","middleName":"Osvaldo","lastName":"Nuttall","gender":"M","birthDate":"1995-02-07T05:00:00.000Z","city":"New York","salary":91990},
    {"firstName":"Harvey","middleName":"Tommie","lastName":"Claire","gender":"M","birthDate":"1955-07-21T04:00:00.000Z","city":"New York","salary":108316},
    {"firstName":"Rolf","middleName":"Leopoldo","lastName":"Altree","gender":"M","birthDate":"1989-01-04T05:00:00.000Z","city":"New York","salary":67581},
    {"firstName":"Geraldo","middleName":"Gavin","lastName":"Meininger","gender":"M","birthDate":"1953-07-14T04:00:00.000Z","city":"New York","salary":64783},
    {"firstName":"Augustus","middleName":"Everette","lastName":"Grishkov","gender":"M","birthDate":"1986-11-06T05:00:00.000Z","city":"New York","salary":66824},
    {"firstName":"Modesto","middleName":"Jeffry","lastName":"Allchin","gender":"M","birthDate":"1954-09-08T04:00:00.000Z","city":"New York","salary":91567},
]

# COMMAND ----------

from pyspark.sql import Row, Column, DataFrame
from pyspark.sql import functions as F

# COMMAND ----------

df_tuples = spark.createDataFrame(data_cities)

df_tuples.printSchema()
df_tuples.show()

# COMMAND ----------

df_tuples.select('Country').dropDuplicates().show()
# distinct () 

# COMMAND ----------

df_tuples.where( F.col("Country")== "USA" ).select('City').show()

# COMMAND ----------

 df_tuples.withColumn("Area_in_mi^2", df_tuples["Area"] * 0.38610).show()

# COMMAND ----------

 df_tuples.withColumn("Density", df_tuples["Population"] / df_tuples["Area"]).show()

# COMMAND ----------

 df_tuples.withColumn("Density", df_tuples["Population"] / df_tuples["Area"]).where( F.col("Country")== "USA" ).agg(
        F.max("Density").alias("Density max"),
        F.avg("Density").alias("Density avg")
    ).show()

# COMMAND ----------

df_tuples.orderBy(df_tuples["Area"]).select('City', "Area").show()

# COMMAND ----------

 df_tuples.withColumn("Density", df_tuples["Population"] / df_tuples["Area"]).groupBy("Country").agg(
   
        F.avg("Density").alias("Density avg")
    ).show()

# COMMAND ----------

df_tuples2 = spark.createDataFrame(data_people)
new_df = df_tuples.join(df_tuples2,df_tuples["City" ]==  df_tuples2["city"],"inner")
# new_df.show()
new_df.groupBy("Country").agg(
   
        F.avg("salary").alias("Salary avg"),
    F.max("salary").alias("Salary max"),
    F.min("salary").alias("Salary min")
    ).withColumn("Salary avg", F.round("Salary avg", 2)).show()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC # MAGIC 1. Get cities in USA ordered by area.
# MAGIC # MAGIC 2. Get cities in USA ordered by population.
# MAGIC # MAGIC 3. Calulate the maximum population density of cities in every country.
# MAGIC # MAGIC 4. Calulate the average population density of cities in every country.
# MAGIC # MAGIC 
# MAGIC # MAGIC ## Part 3 (join)
# MAGIC # MAGIC 1. Get a number of known people in every country.
# MAGIC # MAGIC 2. Get a number of known women in every country.
# MAGIC # MAGIC 3. Get a min, max, avg salary in every country.