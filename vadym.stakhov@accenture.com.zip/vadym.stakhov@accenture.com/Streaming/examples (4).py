# Databricks notebook source
# MAGIC %md # Links
# MAGIC - https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html
# MAGIC - https://docs.delta.io/latest/delta-streaming.html

# COMMAND ----------

from pyspark.sql import functions as F

spark.conf.set("fs.azure.account.key.dbacademystorage1.dfs.core.windows.net", "2oiqmFcFEHb/rdLPM6ntCJqnnjNrRSFyktcNg6jOAtg6EJqVciINduj8Z+X3pWGdzicKB19if2g7/Kx/Xu/Qtw==")

def foreach_batch_function(df, epoch_id):
    print("Batch", epoch_id)
    df.show()
    
metaDF = (spark
              .read
              .format("delta")
              .load("abfss://donath@dbacademystorage1.dfs.core.windows.net/data/metadata")
              .withColumnRenamed("id", "group_id")
         )
    
inputDF = (spark
               .readStream
               .format("delta")
               .option("maxFilesPerTrigger", "10")
               .option("startingVersion", "0")  # value or latest; only matters on the first run with the specified checkpoint
               .load("abfss://donath@dbacademystorage1.dfs.core.windows.net/data/stream")
           )

outputDF = (inputDF
                .withColumn("temp", F.expr("case when unit = 'F' then round((temp - 32) / 1.8, 2) else temp end"))  # F.when(F.col('unit') == 'C', F.col('temp')).when(F.col('unit') == 'F', (F.col('temp')-32)/1.8)
                .drop("unit")
                .withColumn("group_id", F.substring("id", 1, 5))
                .join(metaDF, on="group_id")
                .withColumn("time", F.to_timestamp("time"))  # F.expr("cast(time as timestamp)"), F.col("time").cast("timestamp")
#                 .where("prec > 0")
                .withWatermark("time", "15 minutes")  # watermark 15 minutes on column `time`
                .groupBy(
                    F.window("time", "1 hour").alias("window"),  # tumbling window
                    F.col("country"),
                )
                .agg(
                    F.avg("temp").alias("temp_avg"),
                    F.avg("prec").alias("prec_avg"),
                )
                .withColumn("window_start", F.col("window.start"))
                .withColumn("window_end", F.col("window.end"))
                .drop("window")
                .withColumn("temp_avg", F.round("temp_avg", 2))
                .withColumn("prec_avg", F.round("prec_avg", 2))
           )
    
(outputDF
     .writeStream
     .outputMode("append")
     .foreachBatch(foreach_batch_function)
     .start()
     .awaitTermination()
)

# COMMAND ----------

from pyspark.sql import functions as F

spark.conf.set("fs.azure.account.key.dbacademystorage1.dfs.core.windows.net", "2oiqmFcFEHb/rdLPM6ntCJqnnjNrRSFyktcNg6jOAtg6EJqVciINduj8Z+X3pWGdzicKB19if2g7/Kx/Xu/Qtw==")

def foreach_batch_function(df, epoch_id):
    print("Batch", epoch_id)
    df.show()
    
    
inputDF2 = (spark
               .readStream
               .format("delta")
               .option("maxFilesPerTrigger", "10")
               .option("startingVersion", "0")  # value or latest; only matters on the first run with the specified checkpoint
               .load("abfss://donath@dbacademystorage1.dfs.core.windows.net/data/stream")
           )

outputDF2 = (inputDF2
                .withColumn("temp", F.expr("case when unit = 'F' then round((temp - 32) / 1.8, 2) else temp end"))
                .drop("unit")
                .withColumn("group_id", F.substring("id", 2, 1).cast("int"))
                .withColumn("country", F.expr("case when group_id = 1 then 'Great Britain' when group_id = 2 then 'France' when group_id = 3 then 'Norway' when group_id = 4 then 'Spain' else 'Germany' end"))
                .withColumn("time", F.to_timestamp("time"))  # F.expr("cast(time as timestamp)"), F.col("time").cast("timestamp")
#                 .where("prec > 0")
                .withWatermark("time", "15 minutes")  # watermark 15 minutes on column `time`
                .groupBy(
                    F.window("time", "1 hour").alias("window"),  # tumbling window
                    F.col("country"),
                )
                .agg(
                    F.avg("temp").alias("temp_avg"),
                    F.avg("prec").alias("prec_avg"),
                )
                .withColumn("window_start", F.col("window.start"))
                .withColumn("window_end", F.col("window.end"))
                .drop("window")
                .withColumn("temp_avg", F.round("temp_avg", 2))
                .withColumn("prec_avg", F.round("prec_avg", 2))
           )
    
(outputDF2
     .writeStream
     .outputMode("complete")
     .foreachBatch(foreach_batch_function)
     .start()
     .awaitTermination()
)

# COMMAND ----------

APPEND

Batch 0
+-------+--------+--------+------------+----------+
|country|temp_avg|prec_avg|window_start|window_end|
+-------+--------+--------+------------+----------+
+-------+--------+--------+------------+----------+

Batch 1
+-------+--------+--------+-------------------+-------------------+
|country|temp_avg|prec_avg|       window_start|         window_end|
+-------+--------+--------+-------------------+-------------------+
|Germany|   19.75|     0.0|2014-06-01 12:00:00|2014-06-01 13:00:00|
|Germany|   19.67|     0.0|2014-06-01 11:00:00|2014-06-01 12:00:00|
| Norway|   16.53|     2.1|2014-06-01 12:00:00|2014-06-01 13:00:00|
+-------+--------+--------+-------------------+-------------------+

Batch 2
+-------+--------+--------+------------+----------+
|country|temp_avg|prec_avg|window_start|window_end|
+-------+--------+--------+------------+----------+
+-------+--------+--------+------------+----------+

Batch 3
+-------------+--------+--------+-------------------+-------------------+
|      country|temp_avg|prec_avg|       window_start|         window_end|
+-------------+--------+--------+-------------------+-------------------+
|Great Britain|   27.42|    3.95|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       Norway|   16.38|    1.95|2014-06-01 13:00:00|2014-06-01 14:00:00|
|        Spain|   39.32|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       France|   29.88|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|      Germany|    20.5|    0.14|2014-06-01 13:00:00|2014-06-01 14:00:00|
+-------------+--------+--------+-------------------+-------------------+

# COMMAND ----------

UPDATE

Batch 0
+-------------+--------+--------+-------------------+-------------------+
|      country|temp_avg|prec_avg|       window_start|         window_end|
+-------------+--------+--------+-------------------+-------------------+
|Great Britain|   27.55|    4.18|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       Norway|   16.51|    2.09|2014-06-01 13:00:00|2014-06-01 14:00:00|
|        Spain|   39.53|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|      Germany|   19.75|     0.0|2014-06-01 12:00:00|2014-06-01 13:00:00|
|       France|   29.95|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|      Germany|   19.67|     0.0|2014-06-01 11:00:00|2014-06-01 12:00:00|
|       Norway|   16.53|     2.1|2014-06-01 12:00:00|2014-06-01 13:00:00|
+-------------+--------+--------+-------------------+-------------------+

Batch 1
+-------------+--------+--------+-------------------+-------------------+
|      country|temp_avg|prec_avg|       window_start|         window_end|
+-------------+--------+--------+-------------------+-------------------+
|Great Britain|   27.47|    4.04|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       Norway|   16.44|    2.03|2014-06-01 13:00:00|2014-06-01 14:00:00|
|        Spain|    39.4|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       France|    29.9|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
+-------------+--------+--------+-------------------+-------------------+

Batch 2
+-------------+--------+--------+-------------------+-------------------+
|      country|temp_avg|prec_avg|       window_start|         window_end|
+-------------+--------+--------+-------------------+-------------------+
|Great Britain|   27.42|    3.95|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       Norway|   16.38|    1.95|2014-06-01 13:00:00|2014-06-01 14:00:00|
|        Spain|   38.77|     0.0|2014-06-01 14:00:00|2014-06-01 15:00:00|
|       Norway|   16.07|    1.58|2014-06-01 14:00:00|2014-06-01 15:00:00|
|        Spain|   39.32|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       France|   29.79|     0.0|2014-06-01 14:00:00|2014-06-01 15:00:00|
|Great Britain|   27.14|    3.14|2014-06-01 14:00:00|2014-06-01 15:00:00|
|       France|   29.88|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|      Germany|    20.5|    0.14|2014-06-01 13:00:00|2014-06-01 14:00:00|
+-------------+--------+--------+-------------------+-------------------+

Batch 3
+-------------+--------+--------+-------------------+-------------------+
|      country|temp_avg|prec_avg|       window_start|         window_end|
+-------------+--------+--------+-------------------+-------------------+
|        Spain|   38.73|     0.0|2014-06-01 14:00:00|2014-06-01 15:00:00|
|       Norway|   15.91|    1.39|2014-06-01 14:00:00|2014-06-01 15:00:00|
|       France|   29.62|     0.0|2014-06-01 14:00:00|2014-06-01 15:00:00|
|Great Britain|   27.02|    2.79|2014-06-01 14:00:00|2014-06-01 15:00:00|
+-------------+--------+--------+-------------------+-------------------+

# COMMAND ----------

COMPLETE

Batch 0
+-------------+--------+--------+-------------------+-------------------+
|      country|temp_avg|prec_avg|       window_start|         window_end|
+-------------+--------+--------+-------------------+-------------------+
|Great Britain|   27.55|    4.18|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       Norway|   16.51|    2.09|2014-06-01 13:00:00|2014-06-01 14:00:00|
|        Spain|   39.53|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|      Germany|   19.75|     0.0|2014-06-01 12:00:00|2014-06-01 13:00:00|
|       France|   29.95|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|      Germany|   19.67|     0.0|2014-06-01 11:00:00|2014-06-01 12:00:00|
|       Norway|   16.53|     2.1|2014-06-01 12:00:00|2014-06-01 13:00:00|
+-------------+--------+--------+-------------------+-------------------+

Batch 1
+-------------+--------+--------+-------------------+-------------------+
|      country|temp_avg|prec_avg|       window_start|         window_end|
+-------------+--------+--------+-------------------+-------------------+
|Great Britain|   27.47|    4.04|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       Norway|   16.44|    2.03|2014-06-01 13:00:00|2014-06-01 14:00:00|
|        Spain|    39.4|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|      Germany|   19.92|     0.0|2014-06-01 12:00:00|2014-06-01 13:00:00|
|       France|    29.9|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|      Germany|   19.67|     0.0|2014-06-01 11:00:00|2014-06-01 12:00:00|
|       Norway|   16.53|     2.1|2014-06-01 12:00:00|2014-06-01 13:00:00|
+-------------+--------+--------+-------------------+-------------------+

Batch 2
+-------------+--------+--------+-------------------+-------------------+
|      country|temp_avg|prec_avg|       window_start|         window_end|
+-------------+--------+--------+-------------------+-------------------+
|Great Britain|   27.42|    3.95|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       Norway|   16.38|    1.95|2014-06-01 13:00:00|2014-06-01 14:00:00|
|        Spain|   38.77|     0.0|2014-06-01 14:00:00|2014-06-01 15:00:00|
|       Norway|   16.07|    1.58|2014-06-01 14:00:00|2014-06-01 15:00:00|
|        Spain|   39.32|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       France|   29.79|     0.0|2014-06-01 14:00:00|2014-06-01 15:00:00|
|      Germany|   19.91|     0.0|2014-06-01 12:00:00|2014-06-01 13:00:00|
|Great Britain|   27.14|    3.14|2014-06-01 14:00:00|2014-06-01 15:00:00|
|       France|   29.88|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|      Germany|   19.67|     0.0|2014-06-01 11:00:00|2014-06-01 12:00:00|
|       Norway|   16.53|     2.1|2014-06-01 12:00:00|2014-06-01 13:00:00|
|      Germany|    20.5|    0.14|2014-06-01 13:00:00|2014-06-01 14:00:00|
+-------------+--------+--------+-------------------+-------------------+

Batch 3
+-------------+--------+--------+-------------------+-------------------+
|      country|temp_avg|prec_avg|       window_start|         window_end|
+-------------+--------+--------+-------------------+-------------------+
|Great Britain|   27.42|    3.95|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       Norway|   16.38|    1.95|2014-06-01 13:00:00|2014-06-01 14:00:00|
|        Spain|   38.73|     0.0|2014-06-01 14:00:00|2014-06-01 15:00:00|
|       Norway|   15.91|    1.39|2014-06-01 14:00:00|2014-06-01 15:00:00|
|        Spain|   39.32|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|       France|   29.62|     0.0|2014-06-01 14:00:00|2014-06-01 15:00:00|
|      Germany|   19.92|    0.01|2014-06-01 12:00:00|2014-06-01 13:00:00|
|Great Britain|   27.02|    2.79|2014-06-01 14:00:00|2014-06-01 15:00:00|
|       France|   29.88|     0.0|2014-06-01 13:00:00|2014-06-01 14:00:00|
|      Germany|   19.67|     0.0|2014-06-01 11:00:00|2014-06-01 12:00:00|
|       Norway|   16.53|     2.1|2014-06-01 12:00:00|2014-06-01 13:00:00|
|      Germany|   20.12|    0.39|2014-06-01 13:00:00|2014-06-01 14:00:00|
+-------------+--------+--------+-------------------+-------------------+

# COMMAND ----------

(inputDF
     .writeStream
     .outputMode("append")
  
     .option("checkpointLocation", "abfss://conteiner1@vsrg2t7b5vl27dv2astore.dfs.core.windows.net/output/ver1/checkpoint")
     .format("delta")
     .start("abfss://conteiner1@vsrg2t7b5vl27dv2astore.dfs.core.windows.net/output/ver1/output")
     .awaitTermination()
)

# COMMAND ----------

display( spark.read.format("delta").load("abfss://conteiner1@vsrg2t7b5vl27dv2astore.dfs.core.windows.net/output/ver1/output") )

# COMMAND ----------

spark.conf.set("fs.azure.account.key.vsrg2t7b5vl27dv2astore.dfs.core.windows.net", "SLKcAcJR5Yt8tjEKoYDaY3kzHlf0z13oFsCo57MMh0i1keer3C44s9APtGzE34QoS9ItU6GbhPBiO4DZiZ6tow==")