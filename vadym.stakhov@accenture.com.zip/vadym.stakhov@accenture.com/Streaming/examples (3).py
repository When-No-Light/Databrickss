# Databricks notebook source
# MAGIC %md # Links
# MAGIC - https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html
# MAGIC - https://docs.delta.io/latest/delta-streaming.html

# COMMAND ----------

from pyspark.sql import functions as F

spark.conf.set("fs.azure.account.key.dbacademystorage1.dfs.core.windows.net", "2oiqmFcFEHb/rdLPM6ntCJqnnjNrRSFyktcNg6jOAtg6EJqVciINduj8Z+X3pWGdzicKB19if2g7/Kx/Xu/Qtw==")

def foreach_batch_function(df, epoch_id):
    print("Batch", epoch_id)
    df.show()
    
metaDF = (spark
              .read
              .format("delta")
              .load("abfss://donath@dbacademystorage1.dfs.core.windows.net/data/metadata")
         )
    
inputDF = (spark
               .readStream
               .format("delta")
               .option("maxFilesPerTrigger", "10")
               .option("startingVersion", "latest")  # value or latest; only matters on the first run with the specified checkpoint
               .load("abfss://donath@dbacademystorage1.dfs.core.windows.net/data/stream")
           )

outputDF = (inputDF
#                 .withColumn("temp", F.when(F.col('unit') == 'C', F.col('temp')).when(F.col('unit') == 'F', (F.col('temp')-32)/1.8))
                .withColumn("temp", F.expr("case when unit = 'F' then round((temp - 32) / 1.8, 2) else temp end"))
                .drop("unit")
                .withColumn("group_id", F.substring("id", 1, 5))
           )
    
(outputDF
     .writeStream
     .foreachBatch(foreach_batch_function)
     .start()
     .awaitTermination()
)

# COMMAND ----------

(inputDF
     .writeStream
     .outputMode("append")
     .option("checkpointLocation", "abfss://donath@dbacademystorage1.dfs.core.windows.net/output/ver1/checkpoint")
     .format("delta")
     .start("abfss://donath@dbacademystorage1.dfs.core.windows.net/output/ver1/output")
     .awaitTermination()
)


# COMMAND ----------

display( spark.read.format("delta").load("abfss://donath@dbacademystorage1.dfs.core.windows.net/output/ver1/output") )


# COMMAND ----------

metaDF.show()