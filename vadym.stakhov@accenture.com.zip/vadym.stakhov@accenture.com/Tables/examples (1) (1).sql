-- Databricks notebook source
-- MAGIC %md # SQL

-- COMMAND ----------

select * from parquet.`dbfs:/databricks-datasets/learning-spark-v2/flights/summary-data/parquet/2010-summary.parquet`

-- COMMAND ----------

create database flights

-- COMMAND ----------

-- MAGIC %md ## External table

-- COMMAND ----------

create table flights.flights_external_table (
  origin string,
  destination string,
  count long
)
using parquet
location 'dbfs:/pawel/flights/flights_external_table'

-- COMMAND ----------

-- insert overwrite flights.flights_external_table (origin, destination, count)
--   select ORIGIN_COUNTRY_NAME, DEST_COUNTRY_NAME, count 
--   from parquet.`dbfs:/databricks-datasets/learning-spark-v2/flights/summary-data/parquet/2010-summary.parquet`  -- overwrite

-- insert into flights.flights_external_table (origin, destination, count) values ('Poland', "Ireland", 1)  -- append
-- delete from flights.flights_external_table where origin = 'Poland'  -- not working
-- update flights.flights_external_table set count = 10 where origin = 'Poland'  -- not working

-- COMMAND ----------

drop table flights.flights_external_table  -- delete only metadata

-- COMMAND ----------

select count(*) from flights.flights_external_table

-- COMMAND ----------

select * from flights.flights_external_table

-- COMMAND ----------

-- MAGIC %md ## Internal table

-- COMMAND ----------

create table flights.flights_internal_table (
  origin string,
  destination string,
  count long
)
using parquet
-- /user/hive/warehouse/flights.db/flights_internal_table (conf spark.sql.warehouse.dir)

-- COMMAND ----------

insert overwrite flights.flights_internal_table (origin, destination, count)
  select ORIGIN_COUNTRY_NAME, DEST_COUNTRY_NAME, count 
  from parquet.`dbfs:/databricks-datasets/learning-spark-v2/flights/summary-data/parquet/2010-summary.parquet`  -- overwrite

-- COMMAND ----------

drop table flights.flights_internal_table  -- delete metadata and data

-- COMMAND ----------

select * from flights.flights_internal_table

-- COMMAND ----------

-- MAGIC %md ## Permanent view

-- COMMAND ----------

create view flights.flights_permanent_view as
  select 
    ORIGIN_COUNTRY_NAME as origin, 
    DEST_COUNTRY_NAME as destination, 
    count
  from parquet.`dbfs:/databricks-datasets/learning-spark-v2/flights/summary-data/parquet/2010-summary.parquet`

-- COMMAND ----------

select * from flights.flights_permanent_view

-- COMMAND ----------

-- MAGIC %md ## Global temporary view

-- COMMAND ----------

create global temporary view flights_global_temporary_view as
  select 
    ORIGIN_COUNTRY_NAME as origin, 
    DEST_COUNTRY_NAME as destination, 
    count
  from parquet.`dbfs:/databricks-datasets/learning-spark-v2/flights/summary-data/parquet/2010-summary.parquet`

-- COMMAND ----------

select * from global_temp.flights_global_temporary_view

-- COMMAND ----------

-- MAGIC %md ## Temporary view

-- COMMAND ----------

create temporary view flights_temporary_view as
  select 
    ORIGIN_COUNTRY_NAME as origin, 
    DEST_COUNTRY_NAME as destination, 
    count
  from parquet.`dbfs:/databricks-datasets/learning-spark-v2/flights/summary-data/parquet/2010-summary.parquet`

-- COMMAND ----------

select * from flights_temporary_view

-- COMMAND ----------

-- MAGIC %md ## Source with options

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW tmp_csv_flights
USING csv 
OPTIONS (
  path 'dbfs:/databricks-datasets/learning-spark-v2/flights/summary-data/csv/',
  header true,
  inferSchema true
);
SELECT * FROM tmp_csv_flights;

-- COMMAND ----------

select * from tmp_csv_flights

-- COMMAND ----------

-- MAGIC %md ## Example

-- COMMAND ----------

select
  origin,
  count(distinct destination)
from flights.flights_external_table
group by origin
having count(distinct destination) > 1

-- COMMAND ----------

-- MAGIC %md # Delta

-- COMMAND ----------

-- https://docs.delta.io/latest/index.html
-- https://github.com/delta-io/delta/blob/master/PROTOCOL.md

-- COMMAND ----------

create table flights.flights_external_delta_table (
  origin string,
  destination string,
  count long
)
using delta
location 'dbfs:/pawel/flights/flights_external_delta_table'

-- COMMAND ----------

-- insert overwrite flights.flights_external_delta_table (origin, destination, count)
--   select ORIGIN_COUNTRY_NAME, DEST_COUNTRY_NAME, count 
--   from parquet.`dbfs:/databricks-datasets/learning-spark-v2/flights/summary-data/parquet/2010-summary.parquet`  -- overwrite

-- insert into flights.flights_external_delta_table (origin, destination, count) values ('Poland', "Spain", 1)  -- append
-- delete from flights.flights_external_delta_table where origin = 'Poland'  -- not working
-- update flights.flights_external_delta_table set count = 10 where origin = 'Romania' and destination = 'United States'  -- not working

-- COMMAND ----------

select count(*) from flights.flights_external_delta_table

-- COMMAND ----------

select * from flights.flights_external_delta_table

-- COMMAND ----------

describe history flights.flights_external_delta_table

-- COMMAND ----------

select * from text.`dbfs:/pawel/flights/flights_external_delta_table/_delta_log/00000000000000000004.json`

-- COMMAND ----------

SELECT * FROM flights.flights_external_delta_table@v1 where origin = 'Poland'

-- COMMAND ----------

SET spark.databricks.delta.retentionDurationCheck.enabled = false

-- COMMAND ----------

VACUUM flights.flights_external_delta_table RETAIN 0 HOURS

-- COMMAND ----------

create table flights.flights_external_delta_table2 (
  origin string,
  destination string,
  count long
)
using delta
partitioned by (origin)
location 'dbfs:/pawel/flights/flights_external_delta_table2'

-- COMMAND ----------

insert overwrite flights.flights_external_delta_table2 (origin, destination, count)
  select ORIGIN_COUNTRY_NAME, DEST_COUNTRY_NAME, count 
  from parquet.`dbfs:/databricks-datasets/learning-spark-v2/flights/summary-data/parquet/2010-summary.parquet`  -- overwrite

-- COMMAND ----------



-- COMMAND ----------



-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW departure_delays 
USING csv 
OPTIONS ( path 'dbfs:/databricks-datasets/learning-spark-v2/flights/departuredelays.csv', header true, inferSchema true );


CREATE OR REPLACE TEMPORARY VIEW airport_codes 
USING csv 
OPTIONS ( path 'dbfs:/databricks-datasets/learning-spark-v2/flights/airport-codes-na.txt', header true, delimiter '\t', inferSchema true );


-- COMMAND ----------

SELECT origin, destination, City, AVG (delay) as avg_delay
FROM airport_codes
INNER JOIN departure_delays ON departure_delays.origin = airport_codes.IATA
WHERE delay>0
GROUP BY origin, destination, City

-- COMMAND ----------



-- COMMAND ----------

create table flights.flights_external_delta_table (
  origin string,
  destination string,
  city string,
  avg_delay long
)
using delta
location 'dbfs:/pawel/flights/flights_external_delta_table'

-- COMMAND ----------

insert overwrite flights.flights_external_delta_table2 (origin, destination, city, avg_delay)
  select ORIGIN_COUNTRY_NAME, DEST_COUNTRY_NAME, count 
  from parquet.`dbfs:/databricks-datasets/learning-spark-v2/flights/summary-data/parquet/2010-summary.parquet`  -- overwrite

-- COMMAND ----------



-- COMMAND ----------

flights.flights_external_delta_table