# Databricks notebook source
dbutils.help()

# COMMAND ----------

dbutils.fs.help("ls")

# COMMAND ----------

# MAGIC %md
# MAGIC storage account with databrics

# COMMAND ----------

spark.conf.set("fs.azure.account.key.[].dfs.core.windows.net",
              )

# COMMAND ----------

spark.conf.set()