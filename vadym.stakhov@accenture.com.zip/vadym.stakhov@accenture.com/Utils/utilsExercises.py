# Databricks notebook source
# MAGIC %md
# MAGIC #####Try to recreate steps from panel
# MAGIC 
# MAGIC 1. Load file "/databricks-datasets/flights/departuredelays.csv"
# MAGIC 2. Create a container on storage account
# MAGIC 3. Create a connection between storage account and databricks\
# MAGIC       3.1. by spark conf\
# MAGIC       3.2. by mount point\
# MAGIC       3.3. by SAS token\
# MAGIC       3.4. Save file departuredelays.csv as parquet in container and load back by different type of connection(points: 3.1, 3.2, 3.3)
# MAGIC 4. Try again point 3 with scope\
# MAGIC       4.1. From azure key vault\
# MAGIC       4.2. From Databricks CLI

# COMMAND ----------

from pyspark.sql import Row, Column, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType


# COMMAND ----------

schema = StructType([
    StructField("date", IntegerType ()),
    StructField("delay", IntegerType ()),
    StructField("distance", IntegerType ()),
    StructField("origin", StringType()),
    StructField("destination", StringType()),
    
])

retail_df2 = (spark
                 .read
                 .format("csv")
#                  .option("header", "true")
#                  .option("header", True)
                 
                 .options(header="true")
                 .options(header="true")
                .options(delimiter = ',')
                
                 .schema(schema)
                 .load('dbfs:/databricks-datasets/learning-spark-v2/flights/departuredelays.csv')
                 
            )

retail_df2.printSchema()
display(retail_df2)

# COMMAND ----------

spark.conf.set("fs.azure.account.key.vsrg2t7b5vl27dv2astore.dfs.core.windows.net", "SLKcAcJR5Yt8tjEKoYDaY3kzHlf0z13oFsCo57MMh0i1keer3C44s9APtGzE34QoS9ItU6GbhPBiO4DZiZ6tow==")

# COMMAND ----------

path = "abfss://conteiner1@vsrg2t7b5vl27dv2astore.dfs.core.windows.net"
retail_df2.write.mode("overwrite").format("parquet").save(f"{path}/new1")

# COMMAND ----------

# # path = "abfss://[container]@[storage].dfs.core.windows.net"
# path = "abfss://conteiner1@vsrg2t7b5vl27dv2astore.dfs.core.windows.net"

# df = spark.read.format("csv") \
#     .option("header", "true") \
# .options(delimiter = '|\t')\
# .load(f"{path}/Panel3PandasExcersises.xls")
# df.show()

# COMMAND ----------



# COMMAND ----------

dbutils.fs.mount(
  source = "wasbs://conteiner1@vsrg2t7b5vl27dv2astore.blob.core.windows.net",
  mount_point = "/mnt/first_mount",
  extra_configs = {"fs.azure.account.key.vsrg2t7b5vl27dv2astore.blob.core.windows.net":dbutils.secrets.get(scope = "first-scope", key = "BlobStorageAccessKey1")})


# dbutils.secrets.get(scope = "<scope-name>", key = "<key-name>") gets the key that has been stored as a secret in a secret scope.

# COMMAND ----------

# MAGIC %md
# MAGIC ####Mount an Azure Blob storage container

# COMMAND ----------

container = "conteiner1"
storage_account_name = "vsrg2t7b5vl27dv2astore"
storage_account_key = "SLKcAcJR5Yt8tjEKoYDaY3kzHlf0z13oFsCo57MMh0i1keer3C44s9APtGzE34QoS9ItU6GbhPBiO4DZiZ6tow=="
dbutils.fs.mount(
 source = "wasbs://{0}@{1}.blob.core.windows.net".format(container, storage_account_name),
 mount_point = "/mnt/",
 extra_configs = {"fs.azure.account.key.{0}.blob.core.windows.net".format(storage_account_name): storage_account_key}
)

# COMMAND ----------

dbutils.fs.ls("/mnt/")

# COMMAND ----------

df = spark.read.format("parquet").load("/mnt/new1")
df.show()


# COMMAND ----------

# MAGIC %md
# MAGIC ####SAS token

# COMMAND ----------

storage_account_name = [container]
storage_account_key = [key]
container = [container]
sas = [sasToken]
config = "fs.azure.account.key.[storage].dfs.core.windows.net"

# COMMAND ----------

dbutils.secrets.get(scope = "first-scope", key = "BlobStorageAccessKey1")

# COMMAND ----------

sasKey = "sp=rl&st=2022-04-07T11:13:36Z&se=2022-04-08T19:13:36Z&sv=2020-08-04&sr=c&sig=%2FRxt5dON%2FBbtu9llFJJ58rXKUlZb5qmGqONBKb4wnE4%3D"
storageAccount = "vsrg2t7b5vl27dv2astore"
containerName = "conteiner1"
mountPoint = "/mnt/"
config = "fs.azure.account.key.vsrg2t7b5vl27dv2astore.dfs.core.windows.net"
dbutils.fs.mount(
  source = f"wasbs://{containerName}@{storageAccount}.blob.core.windows.net/",
  mount_point = mountPoint,
  extra_configs = {f"fs.azure.sas.{containerName}.{storageAccount}.blob.core.windows.net": sasKey}
)

# COMMAND ----------

dbutils.fs.unmount("/mnt") 

# COMMAND ----------

df = spark.read.format("parquet").load("/mnt/new1")
df.show()

# COMMAND ----------

dbutils.fs.mounts()

# COMMAND ----------

# MAGIC %md
# MAGIC ####Access with Azure Key Vault

# COMMAND ----------

storage_account_name = "vsrg2t7b5vl27dv2astore"
storage_account_key = "[storage Key]"
container = "conteiner1"

# COMMAND ----------

sasKey = "sp=rl&st=2022-04-07T11:13:36Z&se=2022-04-08T19:13:36Z&sv=2020-08-04&sr=c&sig=%2FRxt5dON%2FBbtu9llFJJ58rXKUlZb5qmGqONBKb4wnE4%3D"
storageAccount = "vsrg2t7b5vl27dv2astore"
containerName = "conteiner1"
mountPoint = "/mnt/"

# COMMAND ----------

storageContainer = "conteiner1"
storageKey = dbutils.secrets.get(scope = "first-scope", key = "BlobStorageAccessKey1")
storageName = "vsrg2t7b5vl27dv2astore"
spark.conf.set(
    f"fs.azure.account.key.{storageName}.dfs.core.windows.net",
    dbutils.secrets.get(scope = "first-scope",key = "BlobStorageAccessKey1"))

# COMMAND ----------

path = f"abfss://{storageContainer}@{storageName}.dfs.core.windows.net"
df = spark.read.format("parquet").load(f"{path}/new1/")
df.show()

# COMMAND ----------

