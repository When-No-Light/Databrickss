# Databricks notebook source
# MAGIC %md
# MAGIC #####dbutils
# MAGIC https://docs.databricks.com/dev-tools/databricks-utils.html

# COMMAND ----------

#used file from dbfs datasets
#"/databricks-datasets/flights/departuredelays.csv"

# COMMAND ----------

dbutils.help()

# COMMAND ----------

dbutils.fs.help()

# COMMAND ----------

dbutils.secrets.help("get")

# COMMAND ----------

# MAGIC %md
# MAGIC #####Data Ingestion

# COMMAND ----------

# MAGIC %md
# MAGIC ####Access Azure Blob storage using the DataFrame API
# MAGIC You need to configure credentials before you can access data in Azure Blob storage, either as session credentials or cluster credentials.
# MAGIC 
# MAGIC 
# MAGIC Set up an account access key:

# COMMAND ----------

# spark.conf.set("fs.azure.account.key.[storage].dfs.core.windows.net", "[key]")
spark.conf.set("fs.azure.account.key.vsrg2t7b5vl27dv2astore.dfs.core.windows.net", "SLKcAcJR5Yt8tjEKoYDaY3kzHlf0z13oFsCo57MMh0i1keer3C44s9APtGzE34QoS9ItU6GbhPBiO4DZiZ6tow==")



# COMMAND ----------

# spark.conf.get("fs.azure.account.key.[storage].dfs.core.windows.net") #get key value
spark.conf.get("fs.azure.account.key.vsrg2t7b5vl27dv2astore.dfs.core.windows.net") #get key value

# COMMAND ----------

# path = "abfss://[container]@[storage].dfs.core.windows.net"
# df = spark.read.format("parquet").load(f"{path}/[file name]")
# df.show()

path = "abfss://conteiner1@vsrg2t7b5vl27dv2astore.dfs.core.windows.net"
df = spark.read.format("parquet").load(f"{path}/[file name]")
df.show()

# COMMAND ----------

spark.conf.unset("fs.azure.account.key.[storage].dfs.core.windows.net")

# COMMAND ----------

path = "wasbs://[container]@[storage].dfs.core.windows.net"
df = spark.read.format("csv").load(f"{path}/[csv file name]")
# df.write.format("csv").save(f"{path}/new2")

# COMMAND ----------

# MAGIC %md
# MAGIC #####Mount an Azure Blob storage container
# MAGIC https://docs.microsoft.com/pl-pl/azure/databricks/data/data-sources/azure/azure-storage

# COMMAND ----------

# dbutils.fs.mount(
#   source = "wasbs://<container-name>@<storage-account-name>.blob.core.windows.net",
#   mount_point = "/mnt/<mount-name>",
#   extra_configs = {"<conf-key>":dbutils.secrets.get(scope = "<scope-name>", key = "<key-name>")})

# <storage-account-name> is the name of your Azure Blob storage account.

# <container-name> is the name of a container in your Azure Blob storage account.

# <mount-name> is a DBFS path representing where the Blob storage container or a folder inside the container (specified in source) will be mounted in DBFS.

# <conf-key> can be either fs.azure.account.key.<storage-account-name>.blob.core.windows.net or fs.azure.sas.<container-name>.<storage-account-name>.blob.core.windows.net

# dbutils.secrets.get(scope = "<scope-name>", key = "<key-name>") gets the key that has been stored as a secret in a secret scope.

# COMMAND ----------

storage_account_name = [storage]
storage_account_key = [key]
container = [container]

# COMMAND ----------

# MAGIC %md
# MAGIC mount with key value

# COMMAND ----------

dbutils.fs.mount(
 source = "wasbs://{0}@{1}.blob.core.windows.net".format(container, storage_account_name),
 mount_point = "/mnt/[mountname]",
 extra_configs = {"fs.azure.account.key.{0}.blob.core.windows.net".format(storage_account_name): storage_account_key}
)

# COMMAND ----------

dbutils.fs.ls("/mnt/[mountname]")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/[mountname]

# COMMAND ----------

df = spark.read.format("parquet").load("/mnt/[mountname]/[fileName]")
df.show()

# COMMAND ----------

dbutils.fs.unmount("/mnt/[mountName]") # unmount directory

# COMMAND ----------

# MAGIC %md
# MAGIC #####Access with other languages
# MAGIC 
# MAGIC https://spark.apache.org/docs/latest/sql-data-sources-parquet.html

# COMMAND ----------

# MAGIC %scala
# MAGIC val sparkDF = spark.read.format("parquet")
# MAGIC .option("header", "true")
# MAGIC .option("inferSchema", "true")
# MAGIC .load("/mnt/[mountName]/[fileName]")
# MAGIC display(sparkDF)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE flightTable
# MAGIC USING parquet
# MAGIC OPTIONS (path "/mnt/[mountName]/[fileName]")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM flightTable

# COMMAND ----------

dbutils.fs.help("unmount")

# COMMAND ----------

# MAGIC %md
# MAGIC ####SAS token
# MAGIC https://www.mssqltips.com/sqlservertip/6931/mount-azure-data-lake-storage-gen2-account-databricks/
# MAGIC 
# MAGIC https://docs.microsoft.com/en-us/azure/storage/common/storage-sas-overview
# MAGIC 
# MAGIC https://gethue.com/blog/2021-06-30-how-to-use-azure-storage-rest-api-with-shared-access-sginature-sas-tokens/
# MAGIC 
# MAGIC https://www.linkedin.com/pulse/configuration-data-sources-databricks-amit-kumar?articleId=6680492780373975040

# COMMAND ----------

storage_account_name = [container]
storage_account_key = [key]
container = [container]
sas = [sasToken]
config = "fs.azure.account.key.[storage].dfs.core.windows.net"

# COMMAND ----------

sasKey = [sasToken]

storageAccount = "[storageName]"
containerName = "[containerName]"
mountPoint = "/mnt/[mountName]"

dbutils.fs.mount(
  source = f"wasbs://{containerName}@{storageAccount}.blob.core.windows.net/",
  mount_point = mountPoint,
  extra_configs = {f"fs.azure.sas.{containerName}.{storageAccount}.blob.core.windows.net": sasKey}
)

# COMMAND ----------

dbutils.fs.ls("/mnt/[mountName]")


# COMMAND ----------

df = spark.read.parquet("/mnt/[mountName]/[fileName]/")
df.show()

# COMMAND ----------

(df
 .write.format("parquet")
 .option("header","True")
 .mode("overwrite")
 .save("/mnt/[mountName]/[fileName]"))

# COMMAND ----------

# MAGIC %md
# MAGIC ######by direct config

# COMMAND ----------

{f"fs.azure.sas.{containerName}.{storageAccount}.blob.core.windows.net": sasKey}

# COMMAND ----------

spark.conf.set("fs.azure.sas.[container].[storage].blob.core.windows.net", [sasToken])

# COMMAND ----------

# MAGIC %md
# MAGIC https://docs.microsoft.com/en-us/azure/databricks/data/data-sources/azure/adls-gen2/azure-datalake-gen2-sas-access

# COMMAND ----------

dbutils.fs.mounts()

# COMMAND ----------

# MAGIC %md
# MAGIC ####Secret Scope

# COMMAND ----------

# MAGIC %md
# MAGIC #####Access with Azure Key Vault

# COMMAND ----------

#secrets/createScope

# COMMAND ----------

storage_account_name = "[storage Name]"
storage_account_key = "[storage Key]"
container = "[container]"

# COMMAND ----------

# MAGIC %md
# MAGIC https://dbacademykeyvault.vault.azure.net/

# COMMAND ----------

storageContainer = dbutils.secrets.get(scope = "storageScope", key = "storageContainer")
storageKey = dbutils.secrets.get(scope = "storageScope", key = "storagekey")
storageName = dbutils.secrets.get(scope = "storageScope", key = "storageName")
spark.conf.set(
    f"fs.azure.account.key.{storageName}.dfs.core.windows.net",
    dbutils.secrets.get(scope = "storageScope",key = "storageKey"))

# COMMAND ----------

path = "abfss://[container]@[storage].dfs.core.windows.net"
df = spark.read.format("parquet").load(f"{path}/[file Name]")
df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC #####secret scope in databrics cli
# MAGIC 
# MAGIC https://docs.databricks.com/dev-tools/cli/index.html
# MAGIC 
# MAGIC pip install databricks-cli

# COMMAND ----------

dbutils.secrets.get(scope = "adbacademy", key = "containerkey") #visibility is blocked

# COMMAND ----------

storage_account_name = "[storage Name]"
container = "[container Name]"
spark.conf.set(
    f"fs.azure.account.key.{storage_account_name}.dfs.core.windows.net",
    dbutils.secrets.get(scope = "[scope Name]",key = "[key Name]"))

# COMMAND ----------

path = "abfss://[container]@[storage].dfs.core.windows.net"
df = spark.read.format("parquet").load(f"{path}/[fileName]")
df.show()

# COMMAND ----------

dbutils.fs.mount(
 source = "wasbs://{0}@{1}.blob.core.windows.net".format(container, storage_account_name),
 mount_point = "/mnt/[mount Name]",
 extra_configs = {"fs.azure.account.key.{0}.blob.core.windows.net".format(storage_account_name): dbutils.secrets.get(scope = "[scope Name]", key = "[secret name]")}
)

# COMMAND ----------

dbutils.fs.ls("/mnt/[mount Name]")