# Databricks notebook source
data_people = [
    {"firstName":"Philomena","middleName":"Jacinta","lastName":"Thunnerclef","gender":"F","birthDate":"1978-11-25T05:00:00.000Z","city":"Ottawa","salary":86568},
    {"firstName":"Eugena","middleName":"Annelle","lastName":"Lupton","gender":"F","birthDate":"1994-06-17T04:00:00.000Z","city":"Ottawa","salary":64352},
    {"firstName":"Natashia","middleName":"Dale","lastName":"Dulwitch","gender":"F","birthDate":"1993-01-23T05:00:00.000Z","city":"Ottawa","salary":94529},
    {"firstName":"Damaris","middleName":"June","lastName":"Roskell","gender":"F","birthDate":"1954-09-16T04:00:00.000Z","city":"Toronto","salary":23155},
    {"firstName":"Tatyana","middleName":"Janet","lastName":"Jurkowski","gender":"F","birthDate":"1953-11-20T05:00:00.000Z","city":"Toronto","salary":56372},
    {"firstName":"Simone","middleName":"Chery","lastName":"Fallis","gender":"F","birthDate":"1989-06-24T04:00:00.000Z","city":"Toronto","salary":84961},
    {"firstName":"Isabell","middleName":"Keiko","lastName":"Chaves","gender":"F","birthDate":"1972-12-07T05:00:00.000Z","city":"Toronto","salary":70857},
    {"firstName":"Valery","middleName":"Sarah","lastName":"Eagles","gender":"F","birthDate":"1956-03-20T05:00:00.000Z","city":"Washington DC","salary":103307},
    {"firstName":"Moira","middleName":"Kathrine","lastName":"Wotton","gender":"F","birthDate":"1999-05-17T04:00:00.000Z","city":"Washington DC","salary":48722},
    {"firstName":"Athena","middleName":"Alma","lastName":"Lethem","gender":"F","birthDate":"1983-07-02T04:00:00.000Z","city":"Washington DC","salary":37678},
    {"firstName":"Ching","middleName":"Lidia","lastName":"Stelfax","gender":"F","birthDate":"1959-06-02T04:00:00.000Z","city":"Washington DC","salary":81668},
    {"firstName":"Eve","middleName":"Kori","lastName":"Wilder","gender":"F","birthDate":"1955-08-23T04:00:00.000Z","city":"Washington DC","salary":59202},
    {"firstName":"Steve","middleName":"Ollie","lastName":"Cullinan","gender":"M","birthDate":"1977-12-27T05:00:00.000Z","city":"Los Angeles","salary":69806},
    {"firstName":"Carter","middleName":"Israel","lastName":"Chapellow","gender":"M","birthDate":"1970-12-17T05:00:00.000Z","city":"Los Angeles","salary":70563},
    {"firstName":"Rolland","middleName":"Marshall","lastName":"Cleave","gender":"M","birthDate":"1974-06-27T04:00:00.000Z","city":"Los Angeles","salary":74752},
    {"firstName":"Mikel","middleName":"Orville","lastName":"MacFayden","gender":"M","birthDate":"1989-07-06T04:00:00.000Z","city":"Chicago","salary":24715},
    {"firstName":"Darrel","middleName":"Raleigh","lastName":"Wisker","gender":"M","birthDate":"1953-08-21T04:00:00.000Z","city":"Chicago","salary":53961},
    {"firstName":"Ernie","middleName":"Boyd","lastName":"Yosselevitch","gender":"M","birthDate":"1990-07-03T04:00:00.000Z","city":"Chicago","salary":25347},
    {"firstName":"Pat","middleName":"Osvaldo","lastName":"Nuttall","gender":"M","birthDate":"1995-02-07T05:00:00.000Z","city":"New York","salary":91990},
    {"firstName":"Harvey","middleName":"Tommie","lastName":"Claire","gender":"M","birthDate":"1955-07-21T04:00:00.000Z","city":"New York","salary":108316},
    {"firstName":"Rolf","middleName":"Leopoldo","lastName":"Altree","gender":"M","birthDate":"1989-01-04T05:00:00.000Z","city":"New York","salary":67581},
    {"firstName":"Geraldo","middleName":"Gavin","lastName":"Meininger","gender":"M","birthDate":"1953-07-14T04:00:00.000Z","city":"New York","salary":64783},
    {"firstName":"Augustus","middleName":"Everette","lastName":"Grishkov","gender":"M","birthDate":"1986-11-06T05:00:00.000Z","city":"New York","salary":66824},
    {"firstName":"Modesto","middleName":"Jeffry","lastName":"Allchin","gender":"M","birthDate":"1954-09-08T04:00:00.000Z","city":"New York","salary":91567},
]

# COMMAND ----------

df_people = spark.createDataFrame(data_people)
df_people.printSchema()
display(df_people)

# COMMAND ----------

import pyspark.sql.functions as F

df_people_with_array = (
    df_people.withColumn("names", F.array("firstName", "middleName", "lastName"))
)
df_people_with_array.printSchema()
display(df_people_with_array)

# COMMAND ----------

df_people_from_array = (
    df_people_with_array
        .withColumn("n", F.explode("names"))
)

df_people_from_array.printSchema()
display(df_people_from_array)

# COMMAND ----------

df_people_from_array_to_columns = (
    df_people_with_array
        .withColumn("n0", F.expr("names[0]"))
        .withColumn("n1", F.expr("names[1]"))
        .withColumn("n2", F.expr("names[2]"))
        .withColumn("n3", F.expr("names[3]"))
)

df_people_from_array_to_columns.printSchema()
display(df_people_from_array_to_columns)

# COMMAND ----------

df_people_with_struct = (
    df_people
        .withColumn("names", F.struct("firstName", "middleName", "lastName"))
        .drop("firstName", "middleName", "lastName")
)
df_people_with_struct.printSchema()
display(df_people_with_struct)

# COMMAND ----------

display( df_people_with_struct.withColumn("last", F.col("names.lastName")) )

# COMMAND ----------

display( df_people_with_struct.select("gender", "salary", "names.*") )

# COMMAND ----------

data_json = [
    ("a", '{"name": "aa", "value": 5}'),
    ("b", '{"name": "bb", "value": 7}'),
    ("c", '{"name": "cc", "value": 9}'),
]
df_json = spark.createDataFrame(data_json, schema=["category", "properties"])
df_json.printSchema()
display(df_json)

# COMMAND ----------

data_json_parsed = df_json.withColumn("properties", F.from_json("properties", schema="name string, value int")).select("category", "properties.*")
data_json_parsed.printSchema()
display(data_json_parsed)

# COMMAND ----------

display(dbutils.fs.ls("dbfs:/databricks-datasets/learning-spark-v2/blogs.json"))

# COMMAND ----------

retail_rdd = sc.textFile("dbfs:/databricks-datasets/learning-spark-v2/blogs.json")
for x in retail_rdd.take(20):
    print(x)

# COMMAND ----------

from pyspark.sql import Row, Column, DataFrame
from pyspark.sql import functions as F

# COMMAND ----------

df_blog = (spark.read)

# COMMAND ----------

retail_df2 = (spark
                 .read
                 .format("json")
#                  .option("header", "true")
#                  .option("header", True)
             
                .options(delimiter = ',')
                
                 
                 .load('dbfs:/databricks-datasets/learning-spark-v2/blogs.json')
                 
            )

retail_df2.printSchema()
display(retail_df2)

# COMMAND ----------

retail_df2 = (
    retail_df2
        .withColumn("n", F.explode("Campaigns"))
)

retail_df2.printSchema()
display(retail_df2)

# COMMAND ----------

print("Group by aggregate")
df_agg_1 = (retail_df2
    .groupBy("n")
    .agg(
        F.max("Hits"),
        F.min("Hits"),
    )
    
)

df_agg_1.printSchema()
df_agg_1.show()

# COMMAND ----------

# MAGIC 
# MAGIC 
# MAGIC %md # Window

# COMMAND ----------

from pyspark.sql import Window as W

window = W.partitionBy("city").orderBy("salary")

df_people_with_window = (
    df_people
        .withColumn("number", F.row_number().over(window))
        .withColumn("lag", F.lag("salary").over(window))
)

display(df_people_with_window)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md # UDF

# COMMAND ----------

from pyspark.sql import types as T

to_upper = F.udf(lambda x: x.upper())
df_people_up = df_people.withColumn("up", to_upper("lastName"))
df_people_up.printSchema()
display( df_people_up )

# COMMAND ----------

@F.udf(returnType=T.IntegerType())
def to_length(x):
    return len(x)

df_people_len = df_people.withColumn("len", to_length("lastName"))
df_people_len.printSchema()
display( df_people_len )

# COMMAND ----------

spark.udf.register("to_reversed", lambda x: x[::-1], T.StringType())
df_people_reversed = df_people.withColumn("rev", F.expr("to_reversed(lastName)"))
df_people_reversed.printSchema()
display(df_people_reversed)

# COMMAND ----------



# COMMAND ----------

s = "1/4/2016"
s[-4:]

# COMMAND ----------

@F.udf(returnType=T.IntegerType())
def to_length(x):
    return int(x[-4:])

df_people_len = retail_df2.withColumn("year", to_length("Published"))
df_people_len.printSchema()
display( df_people_len )

# COMMAND ----------



# COMMAND ----------

# MAGIC %md # Pandas UDF

# COMMAND ----------

import pandas as pd

@F.pandas_udf(T.LongType())
def pandas_length(s: pd.Series) -> pd.Series:
    return s.str.len()
    
df_people_pd = df_people.withColumn("len", pandas_length("lastName"))

df_people_pd.printSchema()
display( df_people_pd )

# COMMAND ----------

@F.pandas_udf(T.LongType())
def pandas_max(s: pd.Series) -> int:
    return s.max()

df_people_agg = df_people.groupBy("city").agg(pandas_max("salary"))
df_people_agg.printSchema()
display(df_people_agg)