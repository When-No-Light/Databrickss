# Databricks notebook source
# MAGIC %md # Nested columns

# COMMAND ----------

data_people = [
    {"firstName":"Philomena","middleName":"Jacinta","lastName":"Thunnerclef","gender":"F","birthDate":"1978-11-25T05:00:00.000Z","city":"Ottawa","salary":86568},
    {"firstName":"Eugena","middleName":"Annelle","lastName":"Lupton","gender":"F","birthDate":"1994-06-17T04:00:00.000Z","city":"Ottawa","salary":64352},
    {"firstName":"Natashia","middleName":"Dale","lastName":"Dulwitch","gender":"F","birthDate":"1993-01-23T05:00:00.000Z","city":"Ottawa","salary":94529},
    {"firstName":"Damaris","middleName":"June","lastName":"Roskell","gender":"F","birthDate":"1954-09-16T04:00:00.000Z","city":"Toronto","salary":23155},
    {"firstName":"Tatyana","middleName":"Janet","lastName":"Jurkowski","gender":"F","birthDate":"1953-11-20T05:00:00.000Z","city":"Toronto","salary":56372},
    {"firstName":"Simone","middleName":"Chery","lastName":"Fallis","gender":"F","birthDate":"1989-06-24T04:00:00.000Z","city":"Toronto","salary":84961},
    {"firstName":"Isabell","middleName":"Keiko","lastName":"Chaves","gender":"F","birthDate":"1972-12-07T05:00:00.000Z","city":"Toronto","salary":70857},
    {"firstName":"Valery","middleName":"Sarah","lastName":"Eagles","gender":"F","birthDate":"1956-03-20T05:00:00.000Z","city":"Washington DC","salary":103307},
    {"firstName":"Moira","middleName":"Kathrine","lastName":"Wotton","gender":"F","birthDate":"1999-05-17T04:00:00.000Z","city":"Washington DC","salary":48722},
    {"firstName":"Athena","middleName":"Alma","lastName":"Lethem","gender":"F","birthDate":"1983-07-02T04:00:00.000Z","city":"Washington DC","salary":37678},
    {"firstName":"Ching","middleName":"Lidia","lastName":"Stelfax","gender":"F","birthDate":"1959-06-02T04:00:00.000Z","city":"Washington DC","salary":81668},
    {"firstName":"Eve","middleName":"Kori","lastName":"Wilder","gender":"F","birthDate":"1955-08-23T04:00:00.000Z","city":"Washington DC","salary":59202},
    {"firstName":"Steve","middleName":"Ollie","lastName":"Cullinan","gender":"M","birthDate":"1977-12-27T05:00:00.000Z","city":"Los Angeles","salary":69806},
    {"firstName":"Carter","middleName":"Israel","lastName":"Chapellow","gender":"M","birthDate":"1970-12-17T05:00:00.000Z","city":"Los Angeles","salary":70563},
    {"firstName":"Rolland","middleName":"Marshall","lastName":"Cleave","gender":"M","birthDate":"1974-06-27T04:00:00.000Z","city":"Los Angeles","salary":74752},
    {"firstName":"Mikel","middleName":"Orville","lastName":"MacFayden","gender":"M","birthDate":"1989-07-06T04:00:00.000Z","city":"Chicago","salary":24715},
    {"firstName":"Darrel","middleName":"Raleigh","lastName":"Wisker","gender":"M","birthDate":"1953-08-21T04:00:00.000Z","city":"Chicago","salary":53961},
    {"firstName":"Ernie","middleName":"Boyd","lastName":"Yosselevitch","gender":"M","birthDate":"1990-07-03T04:00:00.000Z","city":"Chicago","salary":25347},
    {"firstName":"Pat","middleName":"Osvaldo","lastName":"Nuttall","gender":"M","birthDate":"1995-02-07T05:00:00.000Z","city":"New York","salary":91990},
    {"firstName":"Harvey","middleName":"Tommie","lastName":"Claire","gender":"M","birthDate":"1955-07-21T04:00:00.000Z","city":"New York","salary":108316},
    {"firstName":"Rolf","middleName":"Leopoldo","lastName":"Altree","gender":"M","birthDate":"1989-01-04T05:00:00.000Z","city":"New York","salary":67581},
    {"firstName":"Geraldo","middleName":"Gavin","lastName":"Meininger","gender":"M","birthDate":"1953-07-14T04:00:00.000Z","city":"New York","salary":64783},
    {"firstName":"Augustus","middleName":"Everette","lastName":"Grishkov","gender":"M","birthDate":"1986-11-06T05:00:00.000Z","city":"New York","salary":66824},
    {"firstName":"Modesto","middleName":"Jeffry","lastName":"Allchin","gender":"M","birthDate":"1954-09-08T04:00:00.000Z","city":"New York","salary":91567},
]

# COMMAND ----------

df_people = spark.createDataFrame(data_people)
df_people.printSchema()
display(df_people)

# COMMAND ----------

import pyspark.sql.functions as F

df_people_with_array = (
    df_people.withColumn("names", F.array("firstName", "middleName", "lastName"))
)
df_people_with_array.printSchema()
display(df_people_with_array)

# COMMAND ----------

df_people_from_array = (
    df_people_with_array
        .withColumn("n", F.explode("names"))
)

df_people_from_array.printSchema()
display(df_people_from_array)

# COMMAND ----------

df_people_from_array_to_columns = (
    df_people_with_array
        .withColumn("n0", F.expr("names[0]"))
        .withColumn("n1", F.expr("names[1]"))
        .withColumn("n2", F.expr("names[2]"))
        .withColumn("n3", F.expr("names[3]"))
)

df_people_from_array_to_columns.printSchema()
display(df_people_from_array_to_columns)

# COMMAND ----------

df_people_with_struct = (
    df_people
        .withColumn("names", F.struct("firstName", "middleName", "lastName"))
        .drop("firstName", "middleName", "lastName")
)
df_people_with_struct.printSchema()
display(df_people_with_struct)

# COMMAND ----------

display( df_people_with_struct.withColumn("last", F.col("names.lastName")) )

# COMMAND ----------

display( df_people_with_struct.select("gender", "salary", "names.*") )

# COMMAND ----------

data_json = [
    ("a", '{"name": "aa", "value": 5}'),
    ("b", '{"name": "bb", "value": 7}'),
    ("c", '{"name": "cc", "value": 9}'),
]
df_json = spark.createDataFrame(data_json, schema=["category", "properties"])
df_json.printSchema()
display(df_json)

# COMMAND ----------

data_json_parsed = df_json.withColumn("properties", F.from_json("properties", schema="name string, value int")).select("category", "properties.*")
data_json_parsed.printSchema()
display(data_json_parsed)

# COMMAND ----------

# MAGIC %md # Window

# COMMAND ----------

from pyspark.sql import Window as W

window = W.partitionBy("city").orderBy("salary")

df_people_with_window = (
    df_people
        .withColumn("number", F.row_number().over(window))
        .withColumn("lag", F.lag("salary").over(window))
)

display(df_people_with_window)

# COMMAND ----------

# MAGIC %md # UDF

# COMMAND ----------

from pyspark.sql import types as T

to_upper = F.udf(lambda x: x.upper())
df_people_up = df_people.withColumn("up", to_upper("lastName"))
df_people_up.printSchema()
display( df_people_up )

# COMMAND ----------

@F.udf(returnType=T.IntegerType())
def to_length(x):
    return len(x)

df_people_len = df_people.withColumn("len", to_length("lastName"))
df_people_len.printSchema()
display( df_people_len )

# COMMAND ----------

spark.udf.register("to_reversed", lambda x: x[::-1], T.StringType())
df_people_reversed = df_people.withColumn("rev", F.expr("to_reversed(lastName)"))
df_people_reversed.printSchema()
display(df_people_reversed)

# COMMAND ----------

# MAGIC %md # Pandas UDF

# COMMAND ----------

import pandas as pd

@F.pandas_udf(T.LongType())
def pandas_length(s: pd.Series) -> pd.Series:
    return s.str.len()
    
df_people_pd = df_people.withColumn("len", pandas_length("lastName"))

df_people_pd.printSchema()
display( df_people_pd )

# COMMAND ----------

@F.pandas_udf(T.LongType())
def pandas_max(s: pd.Series) -> int:
    return s.max()

df_people_agg = df_people.groupBy("city").agg(pandas_max("salary"))
df_people_agg.printSchema()
display(df_people_agg)

# COMMAND ----------

# MAGIC %md # Cache / persist

# COMMAND ----------

accum = spark.sparkContext.accumulator(0)

@F.udf
def to_lower(x):
    accum.add(1)
    return x.lower()

df_with_cache = df_people.withColumn("low", to_lower("lastName"))

print("Partitions:", df_with_cache.rdd.getNumPartitions())
print("Count:", accum.value)
df_with_cache.persist()
print("Count:", accum.value)
df_with_cache.printSchema()
print("Count:", accum.value)
df_with_cache.show()
print("Count:", accum.value)
df_with_cache.show()
print("Count:", accum.value)
df_with_cache.unpersist()

# COMMAND ----------

# MAGIC %md # Sort

# COMMAND ----------

# 4 files

(df_people
     .select("lastName", "salary")
     .write.mode("overwrite")
     .format("json")
     .save("abfss://donath@dbacademystorage1.dfs.core.windows.net/people/ver1")
)

# COMMAND ----------

# 2 files

(df_people
     .select("lastName", "salary")
     .repartition(2)
     .write
     .mode("overwrite")
     .format("json")
     .save("abfss://donath@dbacademystorage1.dfs.core.windows.net/people/ver2")
)

# COMMAND ----------

# 1 file because we need global sorting

(df_people
     .select("lastName", "salary")
     .orderBy("salary")
     .write
     .mode("overwrite")
     .format("json")
     .save("abfss://donath@dbacademystorage1.dfs.core.windows.net/people/ver3")
)

# COMMAND ----------

# 4 files without shuffling

(df_people
     .select("lastName", "salary")
     .sortWithinPartitions("salary")
     .write
     .mode("overwrite")
     .format("json")
     .save("abfss://donath@dbacademystorage1.dfs.core.windows.net/people/ver4")
)

# COMMAND ----------

# 2 files

(df_people
     .select("lastName", "salary")
     .repartitionByRange(2, "salary")
     .write
     .mode("overwrite")
     .format("json")
     .save("abfss://donath@dbacademystorage1.dfs.core.windows.net/people/ver5")
)

# COMMAND ----------

# 2 files

(df_people
     .select("lastName", "salary")
     .repartitionByRange(2, "salary")
     .sortWithinPartitions("salary")
     .write
     .mode("overwrite")
     .format("json")
     .save("abfss://donath@dbacademystorage1.dfs.core.windows.net/people/ver6")
)

# COMMAND ----------

# 2 files

(df_people
     .select("lastName", "salary")
     .coalesce(2)  # similar to repartition, but only decreasing partition number
     .write
     .mode("overwrite")
     .format("json")
     .save("abfss://donath@dbacademystorage1.dfs.core.windows.net/people/ver7")
)

# COMMAND ----------

# MAGIC %md # Query plan

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType

# display(dbutils.fs.ls("dbfs:/databricks-datasets/learning-spark-v2/flights"))
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "1000")

airports_df = (spark
             .read
             .format("csv")
             .option("inferSchema", True)
             .options(header="true")
             .options(delimiter = '\t')
             .load('dbfs:/databricks-datasets/learning-spark-v2/flights/airport-codes-na.txt' )
            ) 

schema = StructType([
    StructField("date", IntegerType()),
    StructField("delay", IntegerType()),
    StructField("distance", IntegerType()),
    StructField("origin", StringType()),
    StructField("destination", StringType()),
])

delays_df = (spark
    .read
    .format("csv")
    .options(header="true")
    .schema(schema)
    .options(delimiter = ',')
    .load('dbfs:/databricks-datasets/learning-spark-v2/flights/departuredelays.csv')
)

df_result = (delays_df
    .groupBy('origin','destination')
    .agg(
        F.max('delay').alias('max_delay'),
        F.avg('delay').alias('avg_delay'),
        F.min('delay').alias('min_delay')
    )
    .join(F.broadcast(airports_df), on=delays_df["origin"] == airports_df["IATA"])
)

# df_result.explain(mode="extended")
df_result.explain(mode="formatted")

# df_result.show()

# COMMAND ----------

