# Databricks notebook source
# MAGIC %md
# MAGIC #####1.Create the following matrix:
# MAGIC array([[ 0.01,  0.02,  0.03,  0.04,  0.05,  0.06,  0.07,  0.08,  0.09,  0.1 ],\
# MAGIC        [ 0.11,  0.12,  0.13,  0.14,  0.15,  0.16,  0.17,  0.18,  0.19,  0.2 ],\
# MAGIC        [ 0.21,  0.22,  0.23,  0.24,  0.25,  0.26,  0.27,  0.28,  0.29,  0.3 ],\
# MAGIC        [ 0.31,  0.32,  0.33,  0.34,  0.35,  0.36,  0.37,  0.38,  0.39,  0.4 ],\
# MAGIC        [ 0.41,  0.42,  0.43,  0.44,  0.45,  0.46,  0.47,  0.48,  0.49,  0.5 ],\
# MAGIC        [ 0.51,  0.52,  0.53,  0.54,  0.55,  0.56,  0.57,  0.58,  0.59,  0.6 ],\
# MAGIC        [ 0.61,  0.62,  0.63,  0.64,  0.65,  0.66,  0.67,  0.68,  0.69,  0.7 ],\
# MAGIC        [ 0.71,  0.72,  0.73,  0.74,  0.75,  0.76,  0.77,  0.78,  0.79,  0.8 ],\
# MAGIC        [ 0.81,  0.82,  0.83,  0.84,  0.85,  0.86,  0.87,  0.88,  0.89,  0.9 ],\
# MAGIC        [ 0.91,  0.92,  0.93,  0.94,  0.95,  0.96,  0.97,  0.98,  0.99,  1.  ]])

# COMMAND ----------

import numpy as np
np.arange(0.01,1.01,0.01).reshape(10,10)

# COMMAND ----------

# MAGIC %md
# MAGIC #####2.Create an array of 20 linearly spaced points between 0 and 1:
# MAGIC array([ 0.        ,  0.05263158,  0.10526316,  0.15789474,  0.21052632,\
# MAGIC         0.26315789,  0.31578947,  0.36842105,  0.42105263,  0.47368421,\
# MAGIC         0.52631579,  0.57894737,  0.63157895,  0.68421053,  0.73684211,\
# MAGIC         0.78947368,  0.84210526,  0.89473684,  0.94736842,  1.        ])

# COMMAND ----------

np.linspace(0,1,20)

# COMMAND ----------

# MAGIC %md
# MAGIC #####3.Recreate and return result from array
# MAGIC [[ 1  2  3  4  5]\
# MAGIC  [ 6  7  8  9 10]\
# MAGIC  [11 12 13 14 15]\
# MAGIC  [16 17 18 19 20]\
# MAGIC  [21 22 23 24 25]]

# COMMAND ----------

a = np.array([
[ 1, 2, 3, 4, 5],
[ 6, 7 ,8, 9, 10],
[11, 12, 13, 14, 15],
[16, 17, 18, 19, 20],
[21, 22, 23, 24, 25]])

# COMMAND ----------

print(a[3,4])
print(a[:3,1])
print(a[3:5,2:4])
print([a[3,4],a[1,2]])


# COMMAND ----------

# MAGIC %md
# MAGIC 3.1\
# MAGIC     20
# MAGIC     
# MAGIC 3.2\
# MAGIC     [[ 2],\
# MAGIC            [ 7],\
# MAGIC            [12]]
# MAGIC            
# MAGIC 3.3\
# MAGIC     [[18, 19],\
# MAGIC            [23, 24]]
# MAGIC 
# MAGIC 3.4\
# MAGIC [20,  8]

# COMMAND ----------

a.sum()

# COMMAND ----------

a.std()

# COMMAND ----------

a.sum(axis=1)

# COMMAND ----------

# MAGIC %md
# MAGIC 3.5 Get the sum of all the values\
# MAGIC 3.6 Get the standard deviation\
# MAGIC 3.7 Get the sum of all the columns

# COMMAND ----------

# MAGIC %md
# MAGIC #####4.Count "sum / standard deviation" for each column
# MAGIC np.random.seed(50)\
# MAGIC a = np.random.randint(1,30, [5,3])

# COMMAND ----------

np.random.seed(50)
a = np.random.randint(1,30, [5,3])
np.sum(a,axis=0)/np.std(a,axis=0)



# COMMAND ----------

# MAGIC %md
# MAGIC ##### 5. Recreate table and:
# MAGIC np.random.seed(51)\
# MAGIC a = np.random.randint(1,30, [5,3])\
# MAGIC 4.1. Find and return duplicates\
# MAGIC 4.2. Return index of duplicated values\
# MAGIC 4.2. Return number of occurencies of each value in matrix\
# MAGIC 4.3. Replace all '6' number as '20'

# COMMAND ----------

a

# COMMAND ----------

np.random.seed(51)
a = np.random.randint(1,30, [5,3])

# COMMAND ----------

np.unique(a, axis=0, return_index=True, return_counts=True)
u, indices = np.unique(a, return_index=True)

# COMMAND ----------

indices

# COMMAND ----------

a = a.reshape(15,)
sub_array = np.delete(a, indices)
# Find and return duplicates
print(sub_array)

# COMMAND ----------

uniqu_arr, indexes, count =  np.unique(a, return_index=True, return_counts = True)

# COMMAND ----------

a[a==6] =20

# COMMAND ----------

a

# COMMAND ----------

# MAGIC %md
# MAGIC #####6.Pandas
# MAGIC Using moviesMetadata\
# MAGIC 6.1. Show first 10 columns from pandas frame and check the types of data in all columns.\
# MAGIC 6.2. How many null values each column contains?\
# MAGIC 6.3. Display the titles of movies with vote count higher than 7000.\
# MAGIC 6.4. Display movies release years as list with distinct values.\
# MAGIC 6.5. Check out how many movies belongs to each status.\
# MAGIC 6.6. Check out the type of column "realease_date" and change it to the correct format\
# MAGIC 6.7. Change type of "production_countries" column to get following output:\  # =========
# MAGIC 6.8. Display sum of movies produced in US between 2010 and 2020, you need to complete exercises 6 and 7 to complete this task.\# =========
# MAGIC 6.9. Change the type of "budget" column to proper type. What is wrong with this column?\
# MAGIC 6.10. Show mean of the budget for movies in particular countires grouped by years.\ # =========
# MAGIC 6.11. Show count of movies in 2017 with popularity higher than mean of popularity scores in november of 2017

# COMMAND ----------



# COMMAND ----------

import pandas as pd 

# COMMAND ----------

table = pd.read_csv("/dbfs/FileStore/tables/Panel3PandasExcersises.csv")

# COMMAND ----------

table.head(2)

# COMMAND ----------

# test_table = spark.read.options(delimiter=",", header=True).csv("/FileStore/tables/Panel3PandasExcersises.csv")
# test_table = test_table.toPandas()

# COMMAND ----------

table.dtypes[:11]

# COMMAND ----------

table.isnull().sum()

# COMMAND ----------

table[table.vote_count>7000]['title']

# COMMAND ----------

table['release_date'] = pd.to_datetime(table['release_date'], errors='coerce')

# COMMAND ----------

sorted(list(table.release_date.dt.year.drop_duplicates()))

# COMMAND ----------

table.status.value_counts()

# COMMAND ----------

table.release_date.dtypes

# COMMAND ----------



# COMMAND ----------

table.production_countries[0]

# COMMAND ----------

import ast 

def procesing_data(x):
    try:
        if type(x) is str:
            x = ast.literal_eval(x)
            
            #print(x)
            if x:
                l = []
                for i in x:
                    l.append(i['iso_3166_1'])
                #print(l)    
                return l
    
        return np.nan
    except:  
        return np.nan
    

# COMMAND ----------

table.production_countries = table.production_countries.apply(lambda x: procesing_data(x))

# COMMAND ----------

l = ['US']
table[table.production_countries in l ]


# COMMAND ----------

'US' in table.production_countries[0]

# COMMAND ----------

table['budget'] = pd.to_numeric(table['budget'],errors='coerce')

# COMMAND ----------

# Show count of movies in 2017 with popularity higher than mean of popularity scores in november of 2017

# COMMAND ----------

table['popularity'] = pd.to_numeric(table['popularity'],errors='coerce')
mean_popularity_2017_11 = table[(table.release_date.dt.year==2017) & (table.release_date.dt.month==11)]['popularity'].mean()
len(table[(table.popularity>mean_popularity_2017_11) & (table.release_date.dt.year==2017)])

# COMMAND ----------

