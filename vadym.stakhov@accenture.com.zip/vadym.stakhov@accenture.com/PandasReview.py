# Databricks notebook source
# MAGIC %md
# MAGIC ##### Introduction to Pandas
# MAGIC 
# MAGIC Series\
# MAGIC DataFrames\
# MAGIC Missing Data\
# MAGIC GroupBy\
# MAGIC Merging,Joining,and Concatenating\
# MAGIC Operations\
# MAGIC Data Input and Output

# COMMAND ----------

# MAGIC %md
# MAGIC #####Series
# MAGIC A Series is very similar to a NumPy array (in fact it is built on top of the NumPy array object). What differentiates the NumPy array from a Series, is that a Series can have axis labels, meaning it can be indexed by a label, instead of just a number location. It also doesn't need to hold numeric data, it can hold any arbitrary Python Object.

# COMMAND ----------

import numpy as np
import pandas as pd

# COMMAND ----------

# MAGIC %md
# MAGIC #####Creating a Series
# MAGIC You can convert a list,numpy array, or dictionary to a Series:

# COMMAND ----------

labels = ['a','b','c']
my_list = [10,20,30]
arr = np.array([10,20,30])
d = {'a':10,'b':20,'c':30}

# COMMAND ----------

print(pd.Series(data=my_list))
print(pd.Series(data=my_list,index=labels))
print(pd.Series(arr))
print(pd.Series(arr,labels))

# COMMAND ----------

# MAGIC %md
# MAGIC #####Data in a Series
# MAGIC A pandas Series can hold a variety of object types:

# COMMAND ----------

print(pd.Series([10,"a",30]))
print(pd.Series([sum,print,len]))# Even functions (although unlikely that you will use this)


# COMMAND ----------

# MAGIC %md
# MAGIC #####Using an Index
# MAGIC The key to using a Series is understanding its index. Pandas makes use of these index names or numbers by allowing for fast look ups of information (works like a hash table or dictionary).

# COMMAND ----------

ser1 = pd.Series([1,2,3,4],index = ['USA', 'Germany','Poland', 'Japan'])
print(ser1)
ser2 = pd.Series([1,2,5,4],index = ['USA', 'Germany','Italy', 'Japan'])      
print(ser2)
print("")
print(ser1 + ser2)

# COMMAND ----------

# MAGIC %md
# MAGIC #####DataFrames
# MAGIC DataFrames are the workhorse of pandas and are directly inspired by the R programming language. We can think of a DataFrame as a bunch of Series objects put together to share the same index.

# COMMAND ----------

from numpy.random import randn
np.random.seed(101)
df = pd.DataFrame(randn(5,4),index='A B C D E'.split(),columns='W X Y Z'.split())
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Selection and Indexing
# MAGIC Columns

# COMMAND ----------

print(df['W'])

# COMMAND ----------

df[['W','Z']]# Pass a list of column names

# COMMAND ----------

df.W# SQL Syntax

# COMMAND ----------

type(df['W'])

# COMMAND ----------

# MAGIC %md
# MAGIC #####table manipulation

# COMMAND ----------

display(df)

# COMMAND ----------

df['new'] = df['W'] + df['Y']
display(df)

# COMMAND ----------

display(df.drop('new',axis=1))
display(df)

# COMMAND ----------

df.drop('new',axis=1, inplace = True)
display(df)

# COMMAND ----------

df.drop('E',axis=0)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Selecting
# MAGIC Rows

# COMMAND ----------

df

# COMMAND ----------

print(df.loc['A'])
print(type(df.loc['A']))
print(df.iloc[2])#select based off of position instead of label
print(df.loc['B','Y'])#Selecting subset of rows and column
print(df.loc[['A','B'],['W','Y']])

# COMMAND ----------

# MAGIC %md
# MAGIC #####Conditional Selection
# MAGIC An important feature of pandas is conditional selection using bracket notation, very similar to numpy:

# COMMAND ----------

df>0

# COMMAND ----------

df[df>0]

# COMMAND ----------

df[df['W']>0] # filtering by rows

# COMMAND ----------

df[df['W']>0]['Y'] #filtering, row column

# COMMAND ----------

df[df['W']>0][['Y','X']] #returning list of columns with filter

# COMMAND ----------

df[(df['W']>0) & (df['Y'] > 1)] #multiple filter

# COMMAND ----------

# MAGIC %md
# MAGIC #####More Index Details

# COMMAND ----------

df.reset_index()

# COMMAND ----------

newind = 'CA NY WY OR CO'.split()
df['States'] = newind
df.set_index('States')

# COMMAND ----------

df #index wasn't set

# COMMAND ----------

df.set_index('States',inplace=True) #operation need to be applied
df

# COMMAND ----------

# MAGIC %md
# MAGIC #####Multi-Index and Index Hierarchy

# COMMAND ----------

# Index Levels
outside = ['G1','G1','G1','G2','G2','G2']
inside = [1,2,3,1,2,3]
hier_index = list(zip(outside,inside))
print(hier_index)
hier_index = pd.MultiIndex.from_tuples(hier_index)
print(hier_index)

# COMMAND ----------

df = pd.DataFrame(np.random.randn(6,2),index=hier_index,columns=['A','B'])
df

# COMMAND ----------

df.loc['G1']

# COMMAND ----------

df.loc['G1'].loc[1]

# COMMAND ----------

df.index.names#naming indexes
df.index.names = ['Group','Num']
df

# COMMAND ----------

df.xs('G1') #This method takes a key argument to select data at a particular level of a MultiIndex.

# COMMAND ----------

df.xs(['G1',1])

# COMMAND ----------

df.loc['G1'].loc[1]

# COMMAND ----------

df.xs(1,level='Num') #reurn inside index