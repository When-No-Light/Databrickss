# Databricks notebook source
data_cities = [
    {"City":"Atlanta","State":"GA","Country":"USA","Area":343.0,"Population":420003},
    {"City":"Chicago","State":"IL","Country":"USA","Area":606.1,"Population":2763076},
    {"City":"Las Vegas","State":"NV","Country":"USA","Area":340.0,"Population":583756},
    {"City":"Los Angeles","State":"CA","Country":"USA","Area":1302.0,"Population":3999759},
    {"City":"New York","State":"NY","Country":"USA","Area":1213.3,"Population":8336817},
    {"City":"Ottawa","State":"ON","Country":"Canada","Area":2778.64,"Population":945438},
    {"City":"Quebec","State":"PQ","Country":"Canada","Area":485.77,"Population":531902},
    {"City":"San Francisco","State":"CA","Country":"USA","Area":600.7,"Population":852469},
    {"City":"Seattle","State":"WA","Country":"USA","Area":217.4,"Population":713211},
    {"City":"Toronto","State":"ON","Country":"Canada","Area":841.0,"Population":2615060},
    {"City":"Washington DC","Country":"USA","Area":177.0,"Population":705749},
]

data_people = [
    {"firstName":"Philomena","middleName":"Jacinta","lastName":"Thunnerclef","gender":"F","birthDate":"1978-11-25T05:00:00.000Z","city":"Ottawa","salary":86568},
    {"firstName":"Eugena","middleName":"Annelle","lastName":"Lupton","gender":"F","birthDate":"1994-06-17T04:00:00.000Z","city":"Ottawa","salary":64352},
    {"firstName":"Natashia","middleName":"Dale","lastName":"Dulwitch","gender":"F","birthDate":"1993-01-23T05:00:00.000Z","city":"Ottawa","salary":94529},
    {"firstName":"Damaris","middleName":"June","lastName":"Roskell","gender":"F","birthDate":"1954-09-16T04:00:00.000Z","city":"Toronto","salary":23155},
    {"firstName":"Tatyana","middleName":"Janet","lastName":"Jurkowski","gender":"F","birthDate":"1953-11-20T05:00:00.000Z","city":"Toronto","salary":56372},
    {"firstName":"Simone","middleName":"Chery","lastName":"Fallis","gender":"F","birthDate":"1989-06-24T04:00:00.000Z","city":"Toronto","salary":84961},
    {"firstName":"Isabell","middleName":"Keiko","lastName":"Chaves","gender":"F","birthDate":"1972-12-07T05:00:00.000Z","city":"Toronto","salary":70857},
    {"firstName":"Valery","middleName":"Sarah","lastName":"Eagles","gender":"F","birthDate":"1956-03-20T05:00:00.000Z","city":"Washington DC","salary":103307},
    {"firstName":"Moira","middleName":"Kathrine","lastName":"Wotton","gender":"F","birthDate":"1999-05-17T04:00:00.000Z","city":"Washington DC","salary":48722},
    {"firstName":"Athena","middleName":"Alma","lastName":"Lethem","gender":"F","birthDate":"1983-07-02T04:00:00.000Z","city":"Washington DC","salary":37678},
    {"firstName":"Ching","middleName":"Lidia","lastName":"Stelfax","gender":"F","birthDate":"1959-06-02T04:00:00.000Z","city":"Washington DC","salary":81668},
    {"firstName":"Eve","middleName":"Kori","lastName":"Wilder","gender":"F","birthDate":"1955-08-23T04:00:00.000Z","city":"Washington DC","salary":59202},
    {"firstName":"Steve","middleName":"Ollie","lastName":"Cullinan","gender":"M","birthDate":"1977-12-27T05:00:00.000Z","city":"Los Angeles","salary":69806},
    {"firstName":"Carter","middleName":"Israel","lastName":"Chapellow","gender":"M","birthDate":"1970-12-17T05:00:00.000Z","city":"Los Angeles","salary":70563},
    {"firstName":"Rolland","middleName":"Marshall","lastName":"Cleave","gender":"M","birthDate":"1974-06-27T04:00:00.000Z","city":"Los Angeles","salary":74752},
    {"firstName":"Mikel","middleName":"Orville","lastName":"MacFayden","gender":"M","birthDate":"1989-07-06T04:00:00.000Z","city":"Chicago","salary":24715},
    {"firstName":"Darrel","middleName":"Raleigh","lastName":"Wisker","gender":"M","birthDate":"1953-08-21T04:00:00.000Z","city":"Chicago","salary":53961},
    {"firstName":"Ernie","middleName":"Boyd","lastName":"Yosselevitch","gender":"M","birthDate":"1990-07-03T04:00:00.000Z","city":"Chicago","salary":25347},
    {"firstName":"Pat","middleName":"Osvaldo","lastName":"Nuttall","gender":"M","birthDate":"1995-02-07T05:00:00.000Z","city":"New York","salary":91990},
    {"firstName":"Harvey","middleName":"Tommie","lastName":"Claire","gender":"M","birthDate":"1955-07-21T04:00:00.000Z","city":"New York","salary":108316},
    {"firstName":"Rolf","middleName":"Leopoldo","lastName":"Altree","gender":"M","birthDate":"1989-01-04T05:00:00.000Z","city":"New York","salary":67581},
    {"firstName":"Geraldo","middleName":"Gavin","lastName":"Meininger","gender":"M","birthDate":"1953-07-14T04:00:00.000Z","city":"New York","salary":64783},
    {"firstName":"Augustus","middleName":"Everette","lastName":"Grishkov","gender":"M","birthDate":"1986-11-06T05:00:00.000Z","city":"New York","salary":66824},
    {"firstName":"Modesto","middleName":"Jeffry","lastName":"Allchin","gender":"M","birthDate":"1954-09-08T04:00:00.000Z","city":"New York","salary":91567},
]

# COMMAND ----------

rdd_cities = sc.parallelize(data_cities, 3)
print(rdd_cities.collect())

# COMMAND ----------

print( "Distinct:", rdd_cities.map( lambda x: x['Country'] ).distinct().collect() )

# COMMAND ----------

print( "Citys in USA:", rdd_cities.filter( lambda x: x['Country']=='USA' ).map( lambda x: x['City'] ).collect() )

# COMMAND ----------

print( "Show cities with area in mi^2:", rdd_cities.map( lambda x: {x['City'] : x['Area']*0.38610} ).collect() )
# 1 mi =0.38610 

# COMMAND ----------

print( "Density:", rdd_cities.map( lambda x: {x['City'] : x['Population']/x['Area']*0.38610}).collect() )

# COMMAND ----------

rdd_cities.filter( lambda x: x['Country']=='USA' ).map( lambda x:  x['Population']/x['Area']*0.38610).reduce(max)


# COMMAND ----------

# Element zerowy (gdyby kolekcja była pusta, to co zwrócić?)
def avg_zero():
    return {"count": 0, "sum": 0}

# Dodawanie nowego elementu do agregacji
# Wykonuje sie w ramach partycji wejsciowych (przed shuffle, przed wymianą danych)
def avg_add(agg, x):
    return {
        "count": agg["count"] + 1,
        "sum": agg["sum"] + x,
    }

# Łączenie wyników pośrednich
def avg_merge(agg_a, agg_b):
    return {
        "count": agg_a["count"] + agg_b["count"],
        "sum": agg_a["sum"] + agg_b["sum"],
    }
    

result = rdd_cities.filter( lambda x: x['Country']=='Canada' ).map( lambda x:   x['Population']/x['Area']*0.38610).aggregate(zeroValue=avg_zero(), seqOp=avg_add, combOp=avg_merge)
print( "Agg ver2:", result["sum"] / result["count"] )

# COMMAND ----------

# Get cities in USA ordered by area.

print(rdd_cities.filter(lambda x: x['Country']=='USA').map(lambda x: (x['City'],x['Area'])).sortBy(lambda x: x[1], ascending=False).collect())

# COMMAND ----------

# Get cities in USA ordered by population.

print(rdd_cities.filter(lambda x: x['Country']=='USA').map(lambda x: (x['City'],x['Population'])).sortBy(lambda x: x[1], ascending=False).collect())

# COMMAND ----------

# Calulate the maximum population density of cities in every country.

print(rdd_cities.map(lambda x: (x['Country'], x['Population']/x['Area'])).reduceByKey(max).collect())

# COMMAND ----------

# Calulate the average population density of cities in every country.

print( "Average population density", rdd_cities.map(lambda x: (x['Country'], x['Population']/x['Area'])).aggregateByKey(zeroValue=avg_zero(), seqFunc=avg_add, combFunc=avg_merge).mapValues(lambda x: x["sum"] / x["count"]).collect() )


# COMMAND ----------

# Get a number of known people in every country.
# city
rdd_data_people = sc.parallelize(data_people, 2)
# print(rdd_data_people.map(lambda x: (x['city'],1)).collect())

rdd_tuples2 = rdd_data_people.map(lambda x: (x['city'],1))

rdd_tuples = rdd_cities.map(lambda x: (x['City'], x['Country']))
join_tuple = rdd_tuples.join(rdd_tuples2)
join_tuple.map(lambda x: (x[1][0], x[1][1])).reduceByKey( lambda x, y: x + y ).collect()


# COMMAND ----------

# Get a number of known women in every country.
# city
rdd_data_people = sc.parallelize(data_people, 2)
# print(rdd_data_people.map(lambda x: (x['city'],1)).collect())

rdd_tuples2 = rdd_data_people.filter(lambda x: x['gender']=='F').map(lambda x: (x['city'],1))

rdd_tuples = rdd_cities.map(lambda x: (x['City'], x['Country']))
join_tuple = rdd_tuples.join(rdd_tuples2)
join_tuple.map(lambda x: (x[1][0], x[1][1])).reduceByKey( lambda x, y: x + y ).collect()



# COMMAND ----------

# Get a min, max, avg salary in every country. 

rdd_data_people = sc.parallelize(data_people, 2)
# print(rdd_data_people.map(lambda x: (x['city'],1)).collect())

rdd_tuples2 = rdd_data_people.map(lambda x: (x['city'],x['salary']))

rdd_tuples = rdd_cities.map(lambda x: (x['City'], x['Country']))
join_tuple = rdd_tuples.join(rdd_tuples2)
print('Max salary: ',join_tuple.map(lambda x: (x[1][0], x[1][1])).reduceByKey(max).collect())
print('Min salary: ',join_tuple.map(lambda x: (x[1][0], x[1][1])).reduceByKey(min).collect())


print( "Avg salary: ", join_tuple.map(lambda x: (x[1][0], x[1][1])).aggregateByKey(zeroValue=avg_zero(), seqFunc=avg_add, combFunc=avg_merge).mapValues(lambda x: x["sum"] / x["count"]).collect() )






# COMMAND ----------

# Get a min, max, avg salary in every country. 

rdd_data_people = sc.parallelize(data_people, 2)
# print(rdd_data_people.map(lambda x: (x['city'],1)).collect())

rdd_tuples2 = rdd_data_people.map(lambda x: (x['city'],x['salary']))

rdd_tuples = rdd_cities.map(lambda x: (x['City'], x['Country']))
join_tuple = rdd_tuples.join(rdd_tuples2)
print('Max salary: ',join_tuple.map(lambda x: (x[1][0], x[1][1])).reduceByKey(max).collect())
print('Min salary: ',join_tuple.map(lambda x: (x[1][0], x[1][1])).reduceByKey(min).collect())


print( "Avg salary: ", join_tuple.map(lambda x: (x[1][0], x[1][1])).aggregateByKey(zeroValue=avg_zero(), seqFunc=avg_add, combFunc=avg_merge).mapValues(lambda x: x["sum"] / x["count"]).collect() )


# COMMAND ----------

# MAGIC %md # Exercises for every API
# MAGIC ## Part 1 (basic)
# MAGIC 1. Parallelize and show city data.
# MAGIC 2. Show unique countries.
# MAGIC 3. Show cities in USA.
# MAGIC 4. Show cities with area in mi^2 (1 mi^2 = 0.38610 km^2).
# MAGIC 5. Calculate the population density for each city.
# MAGIC 6. Calulate the maximum population density of cities in USA.
# MAGIC 7. Calulate the average population density of cities in Canada.
# MAGIC 
# MAGIC ## Part 2 (group)
# MAGIC 1. Get cities in USA ordered by area.
# MAGIC 2. Get cities in USA ordered by population.
# MAGIC 3. Calulate the maximum population density of cities in every country.
# MAGIC 4. Calulate the average population density of cities in every country.
# MAGIC 
# MAGIC ## Part 3 (join)
# MAGIC 1. Get a number of known people in every country.
# MAGIC 2. Get a number of known women in every country.
# MAGIC 3. Get a min, max, avg salary in every country.