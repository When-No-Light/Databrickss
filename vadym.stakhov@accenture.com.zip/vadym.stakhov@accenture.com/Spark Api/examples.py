# Databricks notebook source
# MAGIC %md
# MAGIC # Links
# MAGIC - https://spark.apache.org/docs/latest/
# MAGIC - https://spark.apache.org/docs/latest/api/python/reference/index.html
# MAGIC - https://sparkbyexamples.com/

# COMMAND ----------

data_numbers = list(range(10))
data_tuples = [
    ("A", 1), ("A", 2), ("A", 3), ("A", 4), ("A", 5),
    ("B", 1), ("B", 3), ("B", 5), ("B", 7), ("B", 9), ("B", 11),
    ("C", 10), ("C", 20), ("C", 30),
]
data_tuples2 = [("A", "X"), ("B", "Y"), ("C", "X"), ("C", "Y")]

# COMMAND ----------

# MAGIC %md # RDD

# COMMAND ----------

# MAGIC %md ## Basic

# COMMAND ----------

# from pyspark import SparkConf, SparkContext

# conf = SparkConf()
# sc = SparkContext(conf=conf)

sc

# COMMAND ----------

rdd_numbers = sc.parallelize(data_numbers, 3)
print( rdd_numbers )
print( rdd_numbers.getNumPartitions() )

# COMMAND ----------

rdd_numbers.foreach(print)

# COMMAND ----------

print( type(rdd_numbers.collect()) )
print( rdd_numbers.collect() )

# COMMAND ----------

# MAGIC %md ## Basic operations

# COMMAND ----------

def square(x):
    return x * x

# print( "Count:", rdd_numbers.count() )
# print( "Map (square):", rdd_numbers.map( square ).collect() )
# print( "Map (double):", rdd_numbers.map( lambda x: x * 2 ).collect() )
# print( "Filter:", rdd_numbers.filter( lambda x: x % 2 ).collect() )
# print( "Reduce:", rdd_numbers.reduce( lambda x, y: x + y ) )
print( "Distinct:", rdd_numbers.map( lambda x: x % 4 ).distinct().collect() )

# COMMAND ----------

print( "Avg ver1:", rdd_numbers.reduce( lambda x, y: x + y ) / rdd_numbers.count() )

# Element zerowy (gdyby kolekcja była pusta, to co zwrócić?)
def avg_zero():
    return {"count": 0, "sum": 0}

# Dodawanie nowego elementu do agregacji
# Wykonuje sie w ramach partycji wejsciowych (przed shuffle, przed wymianą danych)
def avg_add(agg, x):
    return {
        "count": agg["count"] + 1,
        "sum": agg["sum"] + x,
    }

# Łączenie wyników pośrednich
def avg_merge(agg_a, agg_b):
    return {
        "count": agg_a["count"] + agg_b["count"],
        "sum": agg_a["sum"] + agg_b["sum"],
    }
    

result = rdd_numbers.aggregate(zeroValue=avg_zero(), seqOp=avg_add, combOp=avg_merge)
print( "Agg ver2:", result["sum"] / result["count"] )

# COMMAND ----------

# COMMAND ----------

# MAGIC %md ## Key-based operations

# COMMAND ----------

rdd_tuples = sc.parallelize(data_tuples, 2)
# print( "Group:", rdd_tuples.groupByKey().mapValues( lambda iter_x: list(iter_x) ).collect() )
# print( "Reduce by key", rdd_tuples.reduceByKey( lambda x, y: x + y ).collect() )
# print( "Reduce by key + sort", rdd_tuples.reduceByKey( lambda x, y: x + y ).sortByKey(ascending=False).collect() )
# print( "Reduce by key + sort", rdd_tuples.reduceByKey( lambda x, y: x + y ).sortBy( lambda x: x[1] ).collect() )
print( "Aggregate", rdd_tuples.aggregateByKey(zeroValue=avg_zero(), seqFunc=avg_add, combFunc=avg_merge).mapValues(lambda x: x["sum"] / x["count"]).collect() )

# COMMAND ----------

# MAGIC %md ## Join

# COMMAND ----------

rdd_tuples2 = sc.parallelize(data_tuples2, 2)
for x in rdd_tuples.join(rdd_tuples2).collect():
    print(x)

# COMMAND ----------
