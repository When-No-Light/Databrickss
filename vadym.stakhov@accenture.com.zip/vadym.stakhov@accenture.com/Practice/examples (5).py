# Databricks notebook source
# MAGIC %md # Null

# COMMAND ----------

from pyspark.sql import functions as F

dfnull = spark.createDataFrame(
    data=[
        (1, "a", "x", 1.0, 1.0),
        (2, "b", "y", 2.0, -2.0),
        (3, "c", "x", None, None),
        (4, "d", None, 4.0, None),
        (5, None, "x", 5.0, -5.0),
        (6, "f", None, None, -6.0),
        (7, None, "x", None, None),
        (8, None, None, 8.0, 8.0),
        (9, None, None, None, None),
        (None, None, None, None, None),
    ],
    schema=["id", "name", "category", "value1", "value2"]
)

# dfnull.printSchema()
# dfnull.show()

# dfnull.na.drop().show()
# dfnull.na.drop(how="all").show()
# dfnull.na.drop(subset=["name", "category"]).show()

# dfnull.na.fill("-").show()
# dfnull.na.fill(0).show()
# dfnull.na.fill("-", ["category"]).show()

# dfnull.na.replace("x", "-", ["category"]).show()

# dfnull.withColumn("cat2", F.expr("nvl(category, 'ZZZ')")).show()
# dfnull.withColumn("cat2", F.expr("nvl(category, name)")).show()
# dfnull.withColumn("cat2", F.expr("coalesce(category, name, 'ZZZ')")).show()

(dfnull
     .where("id <= 4")
     .drop("id", "name", "category")
     .withColumn("eq1", F.expr("value1 = value2"))  # null if value1 is null or value2 is null
     .withColumn("eq2", F.expr("value1 <=> value2"))  # only true or false (null <=> null is true)
#      .where("eq2")
).show()

# COMMAND ----------

# MAGIC %md # Delta Lake

# COMMAND ----------

df_cities = spark.createDataFrame([
    {"City":"Chicago","State":"IL","Country":"USA","Area":606.1,"Population":2763076},
    {"City":"Los Angeles","State":"CA","Country":"USA","Area":1302.0,"Population":3999759},
    {"City":"New York","State":"NY","Country":"USA","Area":1213.3,"Population":8336817},
    {"City":"Ottawa","State":"ON","Country":"Canada","Area":2778.64,"Population":945438},
    {"City":"Quebec","State":"PQ","Country":"Canada","Area":485.77,"Population":531902},
    {"City":"Washington DC","Country":"USA","Area":177.0,"Population":705749},
])

df_cities.printSchema()
df_cities.show()

# COMMAND ----------

# spark.read.format("delta").load(PATH)
# df_cities.write.format("delta").save(PATH)
# spark.read.table(TABLE_NAME)
# df_cities.write.saveAsTable(TABLE_NAME)

# COMMAND ----------

# MAGIC %md ## Exercise 1
# MAGIC - Create empty table in format delta with columns in order: City, State, Country, Area, Population and types like in the df_cities. Partition by Country
# MAGIC - Then write df_cities to this table.

# COMMAND ----------

# MAGIC %sql
# MAGIC create database cities

# COMMAND ----------

# MAGIC %sql
# MAGIC create table cities.cities_external_delta_table2 (
# MAGIC   City string,
# MAGIC   State string,
# MAGIC   Country string,
# MAGIC   Area long,
# MAGIC   Population long
# MAGIC )
# MAGIC 
# MAGIC using delta
# MAGIC partitioned by (Country)
# MAGIC 
# MAGIC location 'dbfs:/vadym/cities/cities_external_delta_table2'

# COMMAND ----------

df_cities.write.mode("overwrite").format("parquet").partitionBy("Country").save("dbfs:/vadym/df_cities")


# COMMAND ----------

# MAGIC %sql
# MAGIC insert overwrite cities.cities_external_delta_table2 (origin, destination, count)
# MAGIC   select ORIGIN_COUNTRY_NAME, DEST_COUNTRY_NAME, count 
# MAGIC   from parquet.`dbfs:/databricks-datasets/learning-spark-v2/flights/summary-data/parquet/2010-summary.parquet`  -- overwrite

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

spark.createDataFrame([
    {"City":"Quebec","State":"PQ","Country":"Canada","Area":485.77,"Population":531903},
    {"City":"Toronto","State":"ON","Country":"Canada","Area":841.0,"Population":2615060},
]).write.mode("overwrite").option("replaceWhere", "Country='Canada'").saveAsTable("Cities")


# COMMAND ----------

spark.read.table("Cities").show()