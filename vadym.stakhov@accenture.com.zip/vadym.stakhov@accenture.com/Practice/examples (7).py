# Databricks notebook source
# MAGIC %md # Null

# COMMAND ----------

from pyspark.sql import functions as F

dfnull = spark.createDataFrame(
    data=[
        (1, "a", "x", 1.0, 1.0),
        (2, "b", "y", 2.0, -2.0),
        (3, "c", "x", None, None),
        (4, "d", None, 4.0, None),
        (5, None, "x", 5.0, -5.0),
        (6, "f", None, None, -6.0),
        (7, None, "x", None, None),
        (8, None, None, 8.0, 8.0),
        (9, None, None, None, None),
        (None, None, None, None, None),
    ],
    schema=["id", "name", "category", "value1", "value2"]
)

# dfnull.printSchema()
# dfnull.show()

# dfnull.na.drop().show()
# dfnull.na.drop(how="all").show()
# dfnull.na.drop(subset=["name", "category"]).show()

# dfnull.na.fill("-").show()
# dfnull.na.fill(0).show()
# dfnull.na.fill("-", ["category"]).show()

# dfnull.na.replace("x", "-", ["category"]).show()

# dfnull.withColumn("cat2", F.expr("nvl(category, 'ZZZ')")).show()
# dfnull.withColumn("cat2", F.expr("nvl(category, name)")).show()
# dfnull.withColumn("cat2", F.expr("coalesce(category, name, 'ZZZ')")).show()

(dfnull
     .where("id <= 4")
     .drop("id", "name", "category")
     .withColumn("eq1", F.expr("value1 = value2"))  # null if value1 is null or value2 is null
     .withColumn("eq2", F.expr("value1 <=> value2"))  # only true or false (null <=> null is true)
#      .where("eq2")
).show()

# COMMAND ----------

# MAGIC %md # Delta Lake

# COMMAND ----------

df_cities = spark.createDataFrame([
    {"City":"Chicago","State":"IL","Country":"USA","Area":606.1,"Population":2763076},
    {"City":"Los Angeles","State":"CA","Country":"USA","Area":1302.0,"Population":3999759},
    {"City":"New York","State":"NY","Country":"USA","Area":1213.3,"Population":8336817},
    {"City":"Ottawa","State":"ON","Country":"Canada","Area":2778.64,"Population":945438},
    {"City":"Quebec","State":"PQ","Country":"Canada","Area":485.77,"Population":531902},
    {"City":"Washington DC","Country":"USA","Area":177.0,"Population":705749},
])

df_cities.printSchema()
df_cities.show()

# COMMAND ----------

# spark.read.format("delta").load(PATH)
# df_cities.write.format("delta").save(PATH)
# spark.read.table(TABLE_NAME)
# df_cities.write.saveAsTable(TABLE_NAME)

# COMMAND ----------

# MAGIC %md ## Exercise 1
# MAGIC - Create empty table in format delta with columns in order: City, State, Country, Area, Population and types like in the df_cities. Partition by Country
# MAGIC - Then write df_cities to this table.

# COMMAND ----------

spark.sql("""
    create table if not exists Cities (
        City string,
        State string,
        Country string,
        Area double,
        Population long
    )    
    using delta
    partitioned by (Country)
    location 'abfss://donath@dbacademystorage1.dfs.core.windows.net/delta/cities'
""")

# COMMAND ----------

df_cities.write.mode("overwrite").saveAsTable("Cities")

# COMMAND ----------

spark.read.table("Cities").show()

# COMMAND ----------

# Works on Delta Lake
# Works best on a partition column
# Inner data must follow replaceWhere condition

spark.createDataFrame([
    {"City":"Quebec","State":"PQ","Country":"Canada","Area":485.77,"Population":531903},
    {"City":"Toronto","State":"ON","Country":"Canada","Area":841.0,"Population":2615060},
]).write.mode("overwrite").option("replaceWhere", "Country='Canada'").saveAsTable("Cities")

# COMMAND ----------

spark.read.table("Cities").show()

# COMMAND ----------

spark.sql("""
    update Cities set Population = 531902 where City = 'Quebec'
""")

# COMMAND ----------

spark.read.table("Cities").show()

# COMMAND ----------

spark.createDataFrame([
    {"City":"Chicago","State":"IL","Country":"USA","Area":606.1,"Population":2763099},
    {"City":"Las Vegas","State":"NV","Country":"USA","Area":340.0,"Population":583799},
    {"City":"New York","State":"NY","Country":"USA","Area":1213.3,"Population":8336899},
    {"City":"Ottawa","State":"ON","Country":"Canada","Area":2778.64,"Population":945499},
]).createOrReplaceTempView("CitiesChange")

# COMMAND ----------

spark.sql("""
    MERGE INTO Cities AS dst
    USING CitiesChange AS src
    ON dst.City = src.City
    WHEN MATCHED THEN UPDATE SET
        dst.Area = src.Area,
        dst.Population = src.Population
    WHEN NOT MATCHED THEN INSERT (
        City,
        State,
        Country,
        Area,
        Population
    ) VALUES (
        src.City,
        src.State,
        src.Country,
        src.Area,
        src.Population
    )
""")

# COMMAND ----------

spark.read.table("Cities").show()

# COMMAND ----------

spark.createDataFrame([
    {"City":"Chicago","State":"IL","Country":"USA","Area":606.1,"Population":2763077,"Delete":True},
    {"City":"New York","State":"NY","Country":"USA","Area":1213.3,"Population":8336877,"Delete":False},
    {"City":"Ottawa","State":"ON","Country":"Canada","Area":2778.64,"Population":945477,"Delete":False},
    {"City":"Atlanta","State":"GA","Country":"USA","Area":343.0,"Population":420077,"Delete":False},
    {"City":"Seattle","State":"WA","Country":"USA","Area":217.4,"Population":713277,"Delete":True},
    {"City":"Washington DC","Country":"USA","Area":177.0,"Population":705777,"Delete":False},
]).createOrReplaceTempView("CitiesChange")

# COMMAND ----------

spark.sql("""
    MERGE INTO Cities AS dst
    USING CitiesChange AS src
    ON dst.City <=> src.City AND dst.State <=> src.State AND dst.Country <=> src.Country
    WHEN MATCHED AND src.Delete THEN DELETE
    WHEN MATCHED THEN UPDATE SET
        dst.Area = src.Area,
        dst.Population = src.Population
    WHEN NOT MATCHED AND NOT(src.Delete) THEN INSERT (
        City,
        State,
        Country,
        Area,
        Population
    ) VALUES (
        src.City,
        src.State,
        src.Country,
        src.Area,
        src.Population
    )
""")

# COMMAND ----------

spark.read.table("Cities").show()

# COMMAND ----------

