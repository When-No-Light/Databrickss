# Databricks notebook source
dbutils.fs.ls("dbfs:/databricks-datasets/iot-stream/data-device")

# COMMAND ----------

dbutils.fs.ls("dbfs:/databricks-datasets/iot-stream/data-user")

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

devices = (spark
               .read
               .format("json")
               .load("dbfs:/databricks-datasets/iot-stream/data-device")
               .withColumn("timestamp", F.col("timestamp").cast("timestamp"))
               .drop("value")
          )
devices.printSchema()
display(devices)

# COMMAND ----------

users = (spark
             .read
             .format("csv")
             .options(header=True, inferSchema=True)
             .load("dbfs:/databricks-datasets/iot-stream/data-user")
             .withColumnRenamed("height", "tmp")
             .withColumnRenamed("weight", "height")
             .withColumnRenamed("tmp", "weight")
             .drop("tmp")
        )
users.printSchema()
display(users)

# COMMAND ----------

display(users.alias("users")
     .join(devices.alias("devices"), on=F.col("users.userid") == F.col("devices.user_id"))
     .select("users.userid", "devices.miles_walked")
)

# COMMAND ----------

# MAGIC %md
# MAGIC - Policz dzienne agregaty (suma kalorii, odleglosci i krokow) dla wszystkich uzytkownikow dla ktorych znamy historie rodziny i risk jest wiekszy od zera.
# MAGIC - Zapisz wynik do plikow JSON partycjonowanych po dacie i plci.
# MAGIC - Kazdy plik powinien byc wewnetrznie posortowany po sumie krokow (malejaco).

# COMMAND ----------

from pyspark.sql import Row, Column, DataFrame
from pyspark.sql import functions as F

# COMMAND ----------

print("Group by aggregate")

df_agg_1 = (users.alias("users")
     .join(devices.alias("devices"), on=F.col("users.userid") == F.col("devices.user_id"))
     .select("users.userid", "devices.miles_walked", F.date_trunc("day", "devices.timestamp").alias("day"), "devices.calories_burnt", "devices.num_steps", "users.gender") 
    .where((F.col("users.risk") > 0 ) & (F.col("users.familyhistory") == "Y"))
    .groupBy( "users.userid", "day","users.gender")
    .agg(
        F.sum("devices.miles_walked").alias("calories_burnt_sum"),
        F.sum("devices.miles_walked").alias("num_steps_sum"),
        F.sum("devices.miles_walked").alias("miles_walked_sum"),
        
    )
        .withColumn("calories_burnt_sum", F.round("calories_burnt_sum",2))
        .withColumn("num_steps_sum", F.round("num_steps_sum",2))    
        .withColumn("miles_walked_sum", F.round("miles_walked_sum",2))    
        .orderBy("day")
)

df_agg_1.printSchema()
df_agg_1.show()

# COMMAND ----------

df_agg_1.write.mode("overwrite").format("json").partitionBy("day", "gender").save("dbfs:/vadym/json_agg_exercises")

# COMMAND ----------

df_agg_1.repartition("day", "gender").sortWithinPartitions(F.desc("miles_walked_sum")).show()


# COMMAND ----------

df_agg_1.repartition("day", "gender").sortWithinPartitions(F.desc("miles_walked_sum")).write.mode("overwrite").format("json").partitionBy("day", "gender").save("dbfs:/vadym/json_agg_exercises")