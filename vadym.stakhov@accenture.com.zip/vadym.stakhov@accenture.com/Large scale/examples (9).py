# Databricks notebook source
from pyspark.sql import functions as F

basePath = "abfss://donath@dbacademystorage1.dfs.core.windows.net/large"
tmpOutPath = "dbfs:/pawel/tmp/out"

spark.conf.set("fs.azure.account.key.dbacademystorage1.dfs.core.windows.net", "2oiqmFcFEHb/rdLPM6ntCJqnnjNrRSFyktcNg6jOAtg6EJqVciINduj8Z+X3pWGdzicKB19if2g7/Kx/Xu/Qtw==")

# COMMAND ----------

# MAGIC %md # Read
# MAGIC For every directory:
# MAGIC - number of files
# MAGIC - format
# MAGIC - execution time
# MAGIC - tasks duration, number, etc.

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, DateType, TimestampType, LongType, IntegerType, DoubleType

schema = StructType([
    StructField("id", StringType()),
    StructField("time", TimestampType()),
    StructField("date", DateType()),
    StructField("temp", DoubleType()),
    StructField("unit", StringType()),
    StructField("prec", DoubleType()),
    StructField("log", StringType()),
])

# COMMAND ----------

readPath = f"{basePath}/read/data-15"  # data-01 to data-19
files = [f for f in dbutils.fs.ls(readPath) if f.name.startswith("part-")]
print("Number of files:", len(files))
print("Files format:", files[0].name.split(".")[-1])

# COMMAND ----------

(spark
     .read
     .format("parquet")
#      .format("csv").schema(schema)
     .load(readPath)
     .where("date = '2014-07-21'")
     .write
     .mode("overwrite")
     .format("parquet")
     .save(tmpOutPath)
)

# COMMAND ----------

1.9 * 1024 / 128

# COMMAND ----------

inputDF = spark.read.format("parquet").load(f"{basePath}/input")

# COMMAND ----------

inputDF.write.mode("overwrite").format("parquet").save(tmpOutPath)

# COMMAND ----------

inputDF.sortWithinPartitions("time").write.mode("overwrite").format("parquet").save(tmpOutPath)

# COMMAND ----------

inputDF.repartition(8).write.mode("overwrite").format("parquet").save(tmpOutPath)

# COMMAND ----------

inputDF.repartition(8).sortWithinPartitions("time").write.mode("overwrite").format("parquet").save(tmpOutPath)

# COMMAND ----------

inputDF.repartitionByRange(8, "time").write.mode("overwrite").format("parquet").save(tmpOutPath)

# COMMAND ----------

inputDF.repartitionByRange(8, "time").sortWithinPartitions("time").write.mode("overwrite").format("parquet").save(tmpOutPath)

# COMMAND ----------

"""
sort - sortWithinPartitions
range - repartitionByRange

Repartition:
  data-01: repartition_1_block_32M
  data-02: repartition_1_block_128M
  data-03: repartition_1_block_8G
  data-04: repartition_1_sort_block_32M
  data-05: repartition_1_sort_block_128M
  data-06: repartition_1_sort_block_8G

  data-07: repartition_8
  data-08: repartition_8_sort
  data-09: repartition_8_range
  data-10: repartition_8_range_sort

  data-11: repartition_64
  data-12: repartition_64_sort
  data-13: repartition_64_range
  data-14: repartition_64_range_sort

  data-15: repartition_4000

  data-16: csv_repartition_8
  data-17: csv_repartition_8_sort
  data-18: csv_repartition_8_range
  data-19: csv_repartition_8_range_sort
"""

# COMMAND ----------

# MAGIC %md # Broadcast join

# COMMAND ----------

weather = spark.read.format("parquet").load(f"{basePath}/join/weather")
logs = spark.read.format("parquet").load(f"{basePath}/join/logs")
weather.show(4)
logs.show(4)

# COMMAND ----------

(weather
     .join(logs, on="id")
     .write.mode("overwrite").format("parquet").save(tmpOutPath)
)

# COMMAND ----------

(weather
     .join(F.broadcast(logs), on="id")
     .write.mode("overwrite").format("parquet").save(tmpOutPath)
)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md # Nested loop join

# COMMAND ----------

weather_small = spark.read.format("parquet").load(f"{basePath}/join-small/weather")
logs_small = spark.read.format("parquet").load(f"{basePath}/join-small/logs").drop("id")
weather_small.show(4)
logs_small.show(4)

# COMMAND ----------

(weather_small
     .join(logs_small, on=F.expr("id like concat(category, '%')"))
     .write.mode("overwrite").format("parquet").save(tmpOutPath)
)

# COMMAND ----------

(weather_small
     .join(F.broadcast(logs_small), on=F.expr("id like concat(category, '%')"))
     .write.mode("overwrite").format("parquet").save(tmpOutPath)
)

# COMMAND ----------



# COMMAND ----------

weather_prepared = (weather_small
                        .withColumn("key", F.substring("id", 1, 5))
                   )

logs_prepared = (logs_small
                     .withColumn("key", F.substring("category", 1, 5))
                )

(weather_prepared
     .join(logs_prepared, on="key")
     .filter(F.expr("id like concat(category, '%')"))
     .write.mode("overwrite").format("parquet").save(tmpOutPath)
)

# COMMAND ----------

# MAGIC %md # Skew join

# COMMAND ----------

weather_skew = weather_small.withColumn("key", F.expr("case when substring(id, 1, 2) = '01' then '01' else substring(id, 1, 5) end"))
logs_skew = logs_small.withColumn("key", F.expr("case when substring(category, 1, 2) = '01' then '01' else substring(category, 1, 5) end"))
weather_skew.show(4)
logs_skew.show(4)

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 1024)
spark.conf.set("spark.sql.adaptive.autoBroadcastJoinThreshold", "-1")
spark.conf.set("spark.sql.adaptive.advisoryPartitionSizeInBytes", 1024 * 1024)
spark.conf.set("spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes", 2 * 1024 * 1024)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "false")

# COMMAND ----------

(weather_skew
     .join(logs_skew, on="key")
     .write.mode("overwrite").format("parquet").save(tmpOutPath)
)


# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 1024)
spark.conf.set("spark.sql.adaptive.autoBroadcastJoinThreshold", "-1")
spark.conf.set("spark.sql.adaptive.advisoryPartitionSizeInBytes", 1024 * 1024)
spark.conf.set("spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes", 2 * 1024 * 1024)
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")

# COMMAND ----------

(weather_skew
     .join(logs_skew, on="key")
     .write.mode("overwrite").format("parquet").save(tmpOutPath)
)
