# Databricks notebook source
from pyspark.sql import functions as F

basePath = "abfss://donath@dbacademystorage1.dfs.core.windows.net/large"
tmpOutPath = "dbfs:/vadym/tmp/out"

spark.conf.set("fs.azure.account.key.dbacademystorage1.dfs.core.windows.net", "2oiqmFcFEHb/rdLPM6ntCJqnnjNrRSFyktcNg6jOAtg6EJqVciINduj8Z+X3pWGdzicKB19if2g7/Kx/Xu/Qtw==")

# COMMAND ----------

# MAGIC %md # Read
# MAGIC For every directory:
# MAGIC - number of files
# MAGIC - format
# MAGIC - execution time
# MAGIC - tasks duration, number, etc.

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, DateType, TimestampType, LongType, IntegerType, DoubleType

schema = StructType([
    StructField("id", StringType()),
    StructField("time", TimestampType()),
    StructField("date", DateType()),
    StructField("temp", DoubleType()),
    StructField("unit", StringType()),
    StructField("prec", DoubleType()),
    StructField("log", StringType()),
])

# COMMAND ----------

readPath = f"{basePath}/read/data-01"  # data-01 to data-19
files = [f for f in dbutils.fs.ls(readPath) if f.name.startswith("part-")]
print("Number of files:", len(files))
print("Files format:", files[0].name.split(".")[-1])

# COMMAND ----------

(spark
     .read
     .format("parquet")
#      .format("csv").schema(schema)
     .load(readPath)
     .where("date = '2014-07-21'")
     .write
     .mode("overwrite")
     .format("parquet")
     .save(tmpOutPath)
)

# COMMAND ----------

Read
For every directory:

number of files 
format parquet
execution time  29 s
tasks duration   16+1
tasks number     27+2 s
Input   1952.5 MiB
Output  15.1 MiB