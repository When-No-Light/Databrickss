# Databricks notebook source
data_numbers = list(range(10))
data_tuples = [
    ("A", 1), ("A", 2), ("A", 3), ("A", 4), ("A", 5),
    ("B", 1), ("B", 3), ("B", 5), ("B", 7), ("B", 9), ("B", 11),
    ("C", 10), ("C", 20), ("C", 30),
]
data_tuples2 = [("A", "X"), ("B", "Y"), ("C", "X"), ("C", "Y")]

# COMMAND ----------

data_cities = [
    {"City":"Atlanta","State":"GA","Country":"USA","Area":343.0,"Population":420003},
    {"City":"Chicago","State":"IL","Country":"USA","Area":606.1,"Population":2763076},
    {"City":"Las Vegas","State":"NV","Country":"USA","Area":340.0,"Population":583756},
    {"City":"Los Angeles","State":"CA","Country":"USA","Area":1302.0,"Population":3999759},
    {"City":"New York","State":"NY","Country":"USA","Area":1213.3,"Population":8336817},
    {"City":"Ottawa","State":"ON","Country":"Canada","Area":2778.64,"Population":945438},
    {"City":"Quebec","State":"PQ","Country":"Canada","Area":485.77,"Population":531902},
    {"City":"San Francisco","State":"CA","Country":"USA","Area":600.7,"Population":852469},
    {"City":"Seattle","State":"WA","Country":"USA","Area":217.4,"Population":713211},
    {"City":"Toronto","State":"ON","Country":"Canada","Area":841.0,"Population":2615060},
    {"City":"Washington DC","Country":"USA","Area":177.0,"Population":705749},
]

# COMMAND ----------

# MAGIC %md # DataFrame

# COMMAND ----------

spark

# COMMAND ----------

from pyspark.sql import Row, Column, DataFrame
from pyspark.sql import functions as F

# COMMAND ----------

df_numbers = spark.createDataFrame([Row(haha=x) for x in data_numbers])
print( df_numbers )
# df_numbers.show()
display( df_numbers )

# COMMAND ----------

df_tuples = spark.createDataFrame(data_tuples, schema=["name", "value"])
display( df_tuples )

# COMMAND ----------

# print( "Count:", df_tuples.count() )
# print( "RDD:", df_tuples.rdd )
# print( "RDD collect:", df_tuples.rdd.collect() )
df_tuples.printSchema()

# COMMAND ----------

# print( "Add column" )
# df_tuples.withColumn("double", df_tuples["value"] * 2).show()
# df_tuples.withColumn("double", F.col("value") * 2).show()

# print( "Filter columnn" )
# df_tuples.filter( F.col("value") % 2 == 0 ).show()
# df_tuples.where( F.col("value") % 2 == 0 ).show()

# print("Aggregate")
# df_tuples.agg( F.sum("value") ).show()
# df_tuples.agg( F.sum(F.col("value")) ).show()

# COMMAND ----------

print("Group by aggregate")
df_agg_1 = (df_tuples
    .groupBy("name")
    .agg(
        F.count("*").alias("count"),
        F.sum("value").alias("sum"),
        F.collect_list("value").alias("values"),
    )
    .withColumn("sum", F.col("sum").cast("string"))
    .drop("values")
    .select("count", "sum", "name")
    .select(
        F.col("count").alias("my_count"),
        F.col("sum"),
        F.col("name"),
    )
)

df_agg_1.printSchema()
df_agg_1.show()

# COMMAND ----------

rdd_tuples2 = sc.parallelize(data_tuples2)
df_tuples2 = rdd_tuples2.toDF(["name", "category"])

# df_tuples.show()
# df_tuples2.show()

# df_tuples.join(df_tuples2, on="name").show()
(df_tuples
     .join(df_tuples2, on=df_tuples["name"] == df_tuples2["name"], how="inner")
     .orderBy(F.desc("value"))
     .show()
)

# COMMAND ----------

# MAGIC %md # Files

# COMMAND ----------

display(dbutils.fs.ls('/databricks-datasets/online_retail/data-001'))

# COMMAND ----------

retail_rdd = sc.textFile("dbfs:/databricks-datasets/online_retail/data-001/data.csv")
for x in retail_rdd.take(20):
    print(x)

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, TimestampType

schema = StructType([
    StructField("InvoiceNo", StringType()),
    StructField("StockCode", StringType()),
    StructField("Description", StringType()),
    StructField("Quantity", IntegerType()),
    StructField("InvoiceDate", StringType()),
    StructField("UnitPrice", DoubleType()),
    StructField("CustomerID", IntegerType()),
    StructField("Country", StringType()),
    StructField("InvoiceInt", IntegerType()),
])

retail_df = (spark
                 .read
                 .format("csv")
#                  .option("header", "true")
#                  .option("header", True)
#                  .option("inferSchema", True)
                 .options(header="true")
                 .schema(schema)
                 .load("dbfs:/databricks-datasets/online_retail/data-001/data.csv")
                 .withColumn("InvoiceDate", F.to_timestamp("InvoiceDate", "M/d/yy H:m"))
            )

retail_df.printSchema()
display(retail_df)

# COMMAND ----------

retail_df.write.mode("overwrite").format("parquet").save("dbfs:/pawel/retail1")

# COMMAND ----------

retail_df.write.mode("overwrite").format("parquet").partitionBy("Country").save("dbfs:/pawel/retail2")

# COMMAND ----------

schema = StructType([
    StructField("City", StringType()),
    StructField("State", StringType()),
    StructField("Country", StringType()),
    StructField("IATA", StringType()),
    
])

retail_df = (spark
                 .read
                 .format("csv")
#                  .option("header", "true")
#                  .option("header", True)
                 .option("inferSchema", True)
                 .options(header="true")
                 .options(header="true")
                .options(delimiter = '\t')
                
                 .schema(schema)
                 .load('dbfs:/databricks-datasets/learning-spark-v2/flights/airport-codes-na.txt')
                 
            )

retail_df.printSchema()
display(retail_df)

# COMMAND ----------

retail_rdd = sc.textFile("dbfs:/databricks-datasets/learning-spark-v2/flights/airport-codes-na.txt")
for x in retail_rdd.take(20):
    print(x)

# COMMAND ----------

retail_rdd = sc.textFile("dbfs:/databricks-datasets/learning-spark-v2/flights/departuredelays.csv")
for x in retail_rdd.take(20):
    print(x)

# COMMAND ----------

schema = StructType([
    StructField("date", IntegerType ()),
    StructField("delay", IntegerType ()),
    StructField("distance", IntegerType ()),
    StructField("origin", StringType()),
    StructField("destination", StringType()),
    
])

retail_df2 = (spark
                 .read
                 .format("csv")
#                  .option("header", "true")
#                  .option("header", True)
                 
                 .options(header="true")
                 .options(header="true")
                .options(delimiter = ',')
                
                 .schema(schema)
                 .load('dbfs:/databricks-datasets/learning-spark-v2/flights/departuredelays.csv')
                 
            )

retail_df2.printSchema()
display(retail_df2)

# COMMAND ----------

retail_df['IATA']
retail_df2['origin']

new_df = (retail_df2.join(retail_df,retail_df['IATA']==  retail_df2['origin'],"inner").
          select(
              retail_df.City.alias('Origin_city'), 
              retail_df2.origin.alias('Origin_Airport'), 
              retail_df2.delay, 
              retail_df2.distance, 
              retail_df2.destination
          )
        )


new_df2 = new_df.join(retail_df,new_df['destination'] == retail_df['IATA'],"inner")

new_df2 = (new_df2.select(
    new_df2['Origin_city'], 
    new_df2['Origin_Airport'], 
    new_df2.delay, 
    new_df2.distance, 
    new_df2.City.alias('Destination_city'), 
    new_df2.destination.alias('Destination_Airport')
                )
          )


new_df2.show()


# new_df2.select(concat(col("Origin_city"),lit(' - '),
#     col("Destination_Airport")).as("Rout")).show(false)
  

# COMMAND ----------

concat_col_df = (new_df2.withColumn(
    "Rout",
    F.concat(F.col("Origin_city"),
             F.lit(' - '),
    F.col("Destination_city"))
        )
    )

avg_distance = concat_col_df.groupBy("Rout").agg(
    
     F.avg("distance").alias("Distance avg"),
    
    )

avg_distance.show()

# COMMAND ----------

avg_distance.write.mode("overwrite").format("parquet").save("dbfs:/pawel/retail4")

# avg_distance.write.mode("overwrite").format("parquet").partitionBy("Rout").save("dbfs:/pawel/retail5")

# COMMAND ----------

parDF1=spark.read.parquet("dbfs:/pawel/retail4")
parDF1.show()

# COMMAND ----------

r = (spark
        .read
        .format("parquet")
        .load("dbfs:/pawel/retail4"))
r.show(20)

# COMMAND ----------

spark.conf.set("fs.azure.account.key.vsrg2t7b5vl27dv2astore.dfs.core.windows.net", "SLKcAcJR5Yt8tjEKoYDaY3kzHlf0z13oFsCo57MMh0i1keer3C44s9APtGzE34QoS9ItU6GbhPBiO4DZiZ6tow==")


# COMMAND ----------

